---
created: 2025-11-11 09:35
tags: []
---
## Sistema de Logística para Abastecimento na Ucrânia

---

## 📋 Estrutura da Apresentação

**Duração:** 15-20 minutos  
**Formato:** Cada membro apresenta o que implementou + demonstração prática  
**Foco:** Mostrar o que funciona, explicar decisões, apresentar resultados

---

## 👥 Divisão por Implementação Real

### **1. HELDER - Estrutura do Grafo e Carregamento de Dados**

**O que implementou:**

- Estrutura base do grafo (classe Grafo, Nó, Aresta)
- Sistema de carregamento das cidades e conexões
- Representação do mapa da Ucrânia

**O que apresentar (3-4 min):**

1. **Contextualização rápida (30s):**
    
    - "Implementámos um sistema de logística para rotas de abastecimento na Ucrânia usando grafos"
    - "25 cidades ucranianas conectadas por estradas com distâncias reais"
2. **Estrutura implementada (2 min):**
    
    - Mostrar o programa aberto
    - "Construí a estrutura base: um grafo não-direcionado onde cada cidade é um nó e as estradas são arestas com peso"
    - "Usei lista de adjacências porque é mais eficiente para este tipo de grafo onde nem todas as cidades estão diretamente ligadas"
    - Mostrar o mapa visual: "Cada cidade tem coordenadas e o sistema carrega automaticamente as conexões"
3. **Dados e validação (1 min):**
    
    - "O carregamento valida se as conexões são bidirecionais e se não há erros nos dados"
    - Mostrar matriz ou lista de adjacências: "Aqui vemos todas as conexões carregadas"

**Se perguntarem:**

- "Por que lista de adjacências?" → Mais eficiente para grafos esparsos, ocupa menos memória
- "Quantas conexões?" → X arestas conectando 25 cidades (substituir pelo número real)
- "E se uma estrada for bloqueada?" → Podemos remover a aresta e recalcular

---

### **2. ROAN - Algoritmos de Caminho (Dijkstra e TSP)**

**O que implementou:**

- Algoritmo de Dijkstra para caminho mais curto
- Solução para o problema do percurso completo (TSP)
- Cálculo de distâncias e rotas

**O que apresentar (4-5 min):**

1. **Dijkstra - Caminho mais curto (2-3 min):**
    
    - "Implementei o Dijkstra para encontrar o caminho mais curto entre duas cidades"
    - **DEMONSTRAÇÃO PRÁTICA:**
        - Selecionar origem (ex: Kiev) e destino (ex: Odessa)
        - Executar o algoritmo
        - "O resultado mostra: caminho encontrado, distância total, e tempo estimado"
    - Explicar a lógica: "O algoritmo explora cidades mais próximas primeiro, garantindo que encontra sempre o caminho mais curto"
2. **TSP - Percurso completo (2 min):**
    
    - "Para o problema de visitar todas as cidades e voltar ao início, implementei uma solução baseada no vizinho mais próximo"
    - **DEMONSTRAÇÃO PRÁTICA:**
        - Selecionar cidade inicial
        - Executar TSP
        - "Aqui está a rota completa: percorre todas as 25 cidades e retorna"
    - "Esta solução é aproximada mas eficiente. Uma solução perfeita demoraria demasiado tempo para calcular"
3. **Comparação (30s):**
    
    - "Dijkstra é para ir de A para B pelo caminho mais curto"
    - "TSP é para percorrer todos os pontos numa única rota"

**Se perguntarem:**

- "O TSP é óptimo?" → Não, é uma aproximação. TSP óptimo é impraticável para 25 cidades
- "Tempo de execução?" → Dijkstra é rápido mesmo para grafos grandes. TSP também roda em segundos
- "E se houver empate?" → O algoritmo escolhe uma das opções válidas

---

### **3. LAYZA - Árvores Geradoras Mínimas (Kruskal e Prim)**

**O que implementou:**

- Algoritmo de Kruskal
- Algoritmo de Prim
- Estrutura Union-Find para detecção de ciclos
- Visualização das árvores resultantes

**O que apresentar (4-5 min):**

1. **O que é e para que serve (1 min):**
    
    - "Implementei dois algoritmos para encontrar a forma mais económica de conectar todas as cidades: Kruskal e Prim"
    - "É como se precisássemos construir estradas novas: estes algoritmos dizem quais construir para ligar tudo gastando o mínimo"
2. **Demonstração Kruskal (1-2 min):**
    
    - VRITIK executa Kruskal
    - Mostrar resultado visual da árvore
    - "Vejam: conectou todas as 25 cidades usando apenas X km de estradas" (substituir por valor real)
    - "Se usássemos todas as estradas existentes, seria Y km" (mostrar diferença)
    - "O Kruskal ordena todas as estradas por distância e vai escolhendo as menores, evitando ciclos"
3. **Demonstração Prim (1-2 min):**
    
    - VRITIK executa Prim
    - "O Prim faz o mesmo, mas de forma diferente: começa numa cidade e vai crescendo a árvore escolhendo sempre a conexão mais barata"
    - Comparar resultados: "Ambos dão o mesmo custo total, mas podem escolher estradas diferentes"
4. **Detalhes técnicos (30s-1min):**
    
    - "No Kruskal, usei Union-Find para detectar ciclos de forma eficiente"
    - "No Prim, uso uma fila de prioridade para sempre expandir pela aresta mais barata"

**Se perguntarem:**

- "Diferença entre Kruskal e Prim?" → Kruskal trabalha com todas as arestas globalmente, Prim cresce a partir de um ponto. Para este grafo, ambos funcionam bem
- "Sempre dão o mesmo resultado?" → Mesmo custo total, mas podem escolher arestas diferentes se houver empates
- "Qual é melhor?" → Depende da estrutura. Kruskal melhor para grafos esparsos, Prim melhor para grafos densos
- "Aplicação prática?" → Planeamento de redes (estradas, internet, energia, água, electricidade)

---

### **4. TAMARA - Algoritmos de Busca (BFS e DFS)**

**O que implementou:**

- Busca em Largura (BFS)
- Busca em Profundidade (DFS)
- Análise de conectividade do grafo

**O que apresentar (3-4 min):**

1. **BFS - Busca em Largura (1-2 min):**
    
    - "Implementei o BFS que explora o grafo por níveis, como ondas expandindo"
    - **DEMONSTRAÇÃO:**
        - Selecionar uma cidade inicial
        - Executar BFS
        - "Mostra a ordem em que as cidades são visitadas, começando pelas mais próximas"
    - "É útil para encontrar o caminho com menos saltos, mesmo que não seja o mais curto em distância"
2. **DFS - Busca em Profundidade (1-2 min):**
    
    - "O DFS explora um caminho até ao fim antes de tentar outro"
    - **DEMONSTRAÇÃO:**
        - Executar DFS
        - Comparar a ordem com o BFS
    - "A ordem é diferente porque a estratégia de exploração é diferente"
3. **Análise do grafo (1 min):**
    
    - "Também implementei análises sobre a estrutura:"
    - Mostrar: "O grafo é conexo (há caminho entre quaisquer duas cidades)"
    - "Identifiquei cidades críticas: se forem bloqueadas, isolam outras partes do grafo"
    - "Calculei o grau médio: quantas conexões cada cidade tem em média"

**Se perguntaram:**

- "BFS vs DFS, qual é melhor?" → Depende do problema. BFS para caminho mais curto não-ponderado, DFS para exploração completa
- "Como identifica cidades críticas?" → Removo temporariamente cada cidade e verifico se o grafo fica desconectado
- "Para que serve isto?" → Análise de vulnerabilidade. Se uma cidade crítica cair, o sistema falha

---

### **5. VRITIK - Operador da Interface + Funcionalidades Dinâmicas**

**PAPEL NA APRESENTAÇÃO:**

- Opera a interface durante toda a apresentação
- Executa os algoritmos quando cada colega pede
- Apresenta as suas implementações específicas quando chegar a sua vez

**O que implementou:**

- Sistema de adição/remoção de cidades e conexões
- Geração de relatórios PDF
- Exportação da matriz para Excel
- Animações dos algoritmos
- Sistema de visualizações

**O que apresentar (4-5 min):**

1. **Funcionalidades dinâmicas (2-3 min):**
    
    - **Adicionar cidade:**
        - "Implementei a possibilidade de adicionar novas cidades ao sistema"
        - Demonstrar: adicionar uma cidade
        - "Basta inserir nome, coordenadas, e definir as conexões com outras cidades"
        - Executar um algoritmo qualquer para mostrar que funciona: "A nova cidade já está integrada"
    - **Remover cidade:**
        - "Também posso remover cidades e o sistema recalcula tudo automaticamente"
        - Demonstrar: remover uma cidade
        - "Vejam como o grafo se ajusta"
    - **Adicionar/remover conexões:**
        - "Posso modificar as estradas: adicionar ou remover conexões entre cidades"
        - Demonstrar mudança de uma conexão
        - "Útil para simular bloqueios ou novas rotas"
2. **Exportações e relatórios (1-2 min):**
    
    - **Exportar matriz para Excel:**
        - Clicar em exportar matriz
        - "A matriz de adjacências pode ser exportada para Excel para análise externa"
        - Abrir o ficheiro gerado: "Aqui está a matriz completa em formato editável"
    - **Gerar relatório PDF:**
        - Executar geração de PDF
        - "O sistema compila todos os resultados dos algoritmos num relatório profissional"
        - Abrir PDF: "Inclui estatísticas, análises, rotas calculadas, e visualizações"
3. **Visualizações e animações (30s-1min):**
    
    - "Durante a apresentação, vocês viram as animações dos algoritmos a trabalhar"
    - "E as diferentes formas de visualizar os dados: matriz, listas, grafo visual"
    - "Tudo isto facilita a compreensão do que está a acontecer no sistema"

**Se perguntarem:**

- "O que acontece se remover uma cidade crítica?" → O sistema detecta e pode alertar, ou recalcula os algoritmos
- "As alterações são permanentes?" → Sim, mas podemos recarregar os dados originais
- "O Excel exporta apenas a matriz?" → Sim, especificamente a matriz. O PDF é que tem tudo
- "E se adicionar dados inválidos?" → O sistema valida e mostra erro antes de aceitar

---

## 🎯 Fluxo de Demonstração Sugerido

**IMPORTANTE:** VRITIK opera a interface durante TODA a apresentação. Quando os outros falam, ele executa. Quando for a vez dele, ele apresenta as funcionalidades que implementou (adicionar/remover, exportações).

### **Sequência integrada:**

1. **HELDER abre e contextualiza (1 min)**
    
    - Apresenta o problema e pede ao Vritik para mostrar o mapa
2. **Cenário prático (10-12 min):**
    
    _"Vamos simular um caso real: um comboio de abastecimento precisa sair de Kiev"_
    
    - **ROAN:** "Primeiro, qual o caminho mais curto até Odessa?"
        - VRITIK executa Dijkstra
        - ROAN explica o resultado
    - **ROAN:** "E se precisarmos visitar todas as cidades?"
        - VRITIK executa TSP
        - ROAN analisa a rota completa
    - **LAYZA:** "Para construir infraestrutura nova, a rede óptima seria esta"
        - VRITIK executa Kruskal
        - LAYZA explica resultado
        - VRITIK executa Prim
        - LAYZA compara os dois algoritmos
    - **TAMARA:** "Para analisar vulnerabilidades do sistema"
        - VRITIK executa análise
        - TAMARA explica cidades críticas
    - **VRITIK (agora fala das funcionalidades dele):**
        - "Também implementei funcionalidades dinâmicas"
        - Adiciona uma cidade nova, mostra que integra
        - Remove uma cidade, recalcula
        - Exporta matriz para Excel, mostra ficheiro
        - Gera relatório PDF completo
        - "Todo o processo fica documentado e os dados são editáveis"
3. **Fechamento (2-3 min - todos)**
    
    - Recapitular funcionalidades principais
    - Abrir para perguntas

---

## 💡 Orientações Gerais

### **O que fazer:**

✅ Explicar o que fizeste, não teoria geral de grafos  
✅ Mostrar funcionando - demonstração vale mais que explicação  
✅ Mencionar decisões: "escolhi X porque Y"  
✅ Usar a linguagem do enunciado quando relevante (Oblasts, comboio, abastecimento)  
✅ Conectar com o trabalho dos colegas: "isso integra com o que o Helder implementou"  
✅ Estar preparado para fazer alterações no código durante a defesa

### **O que evitar:**

❌ Recitar teoria que não usaste  
❌ Entrar em detalhes da interface (cores, botões) - não é o foco  
❌ Ler código linha a linha  
❌ Dizer "basicamente", "tipo", "mais ou menos"  
❌ Ficar só na teoria sem demonstrar  
❌ Falar de complexidades sem contexto (só se perguntarem)

---

## 📊 Dados Essenciais a Saber

### **Estrutura:**

- 25 cidades ucranianas
- X arestas (conexões directas)
- Grafo não-direcionado e ponderado
- Representação: lista de adjacências

### **Algoritmos implementados:**

- Dijkstra (caminho mais curto)
- TSP heurístico (percurso completo)
- Kruskal (árvore geradora mínima)
- BFS e DFS (buscas)
- Análises (conectividade, nós críticos, grau médio)

### **Funcionalidades:**

- Visualizações (matriz, listas, grafo visual)
- Animações dos percursos
- Relatórios PDF automáticos
- Interface interactiva completa

---

## 🎓 Perguntas Prováveis

**"Por que lista de adjacências?"** → Mais eficiente para grafos com poucas conexões. Ocupa menos memória.

**"O TSP está correcto?"** → É uma aproximação boa, não óptima. TSP óptimo demora demasiado tempo.

**"Como garantem que funciona?"** → Testámos com casos conhecidos, validámos as distâncias, verificámos conectividade.

**"E se mudarem os dados?"** → O sistema é flexível. Podemos adicionar/remover cidades, ajustar distâncias.

**"Qual o algoritmo mais eficiente?"** → Depende do problema. Para caminho único, Dijkstra. Para percurso completo, TSP. Para infraestrutura, Kruskal.

**"Aplicações reais?"** → GPS (Dijkstra), rotas de entregas (TSP), redes de comunicação (Kruskal), análise de vulnerabilidade (nós críticos).

**Durante a defesa: "Removam a cidade X e recalculem"** → [Ir ao código, remover, executar novamente, mostrar diferença]

**Durante a defesa: "Adicionem uma nova cidade Y"** → [Mostrar onde está o ficheiro de dados, adicionar, recarregar, testar]

---

## ✅ Checklist Final

Antes da apresentação, garantir que:

- [ ] Programa compila sem erros
- [ ] Todos os algoritmos funcionam
- [ ] Sabem demonstrar cada funcionalidade
- [ ] Testaram o PDF
- [ ] Conhecem o código minimamente (onde está cada coisa)
- [ ] Têm respostas preparadas para perguntas comuns
- [ ] Cronometraram (15-20 min)
- [ ] Backup do código disponível
- [ ] Laptop carregado / projetor funciona

---

## 🎬 Divisão Real vs. Divisão da Apresentação

**Clarificação importante:**

VRITIK não apresenta "a interface". Interface é transversal - todos usam, todos navegam.

VRITIK tem dois papéis:

1. **Durante a apresentação dos outros:** Opera o sistema (executa algoritmos, muda visualizações)
2. **Na sua parte:** Apresenta o que **implementou especificamente**:
    - Sistema de adicionar/remover cidades e conexões
    - Exportação para Excel
    - Geração de PDF
    - Animações dos algoritmos

**O que está no código:**

- Estruturas, algoritmos, funcionalidades - tudo distribuído

**O que interessa na apresentação:**

- Cada um fala do que **implementou**
- Demonstra **funcionando**
- Explica **decisões tomadas**
- Mostra **resultados**

O foco é sempre: "isto funciona, fui eu que fiz, tomei estas decisões, aqui estão os resultados."

---

**Boa apresentação! 🚀**