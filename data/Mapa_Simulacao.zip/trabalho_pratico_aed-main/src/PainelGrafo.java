//package views;

import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import models.No;
import models.Aresta;
import javax.sound.sampled.*;
import java.io.ByteArrayInputStream;

/**
 * PainelGrafo (versão holográfica integrada)
 * 
 * Mescla a UX original (adição, remoção, ligação, destaque de caminhos)
 * com uma camada visual holográfica: fundo animado, arestas destacadas
 * desenhadas por curvas QuadCurve2D e partículas de fluxo contínuo azul→amarelo.
 *
 * Mantém todas as funcionalidades originais — apenas altera a renderização
 * e adiciona controle de animação via iniciarAnimacao()/pararAnimacao().
 */
public class PainelGrafo extends JPanel {
    private List<No> cidades;
    private List<Aresta> conexoes;
    private List<Aresta> caminhoDestacado;
    private JFrame frameParent;
    private Runnable atualizarComboboxCallback;
    private JLabel labelInfo;

    // Visual: cores base
    private static final Color COR_FUNDO_A = new Color(6, 20, 40);
    private static final Color COR_FUNDO_B = new Color(2, 48, 89);
    private static final Color COR_ARESTA_NORMAL = new Color(203, 213, 225);
    private static final Color COR_ARESTA_DESTAQUE = new Color(80, 170, 255); // base azul para destaque
    private static final Color COR_NO_NORMAL = new Color(59, 130, 246);
    private static final Color COR_NO_DESTAQUE = new Color(255, 215, 80); // dourado para labels / brilho
    private static final Color COR_TEXTO = new Color(230, 240, 255);
    private static final Color COR_TEXTO_PESO = new Color(200, 210, 220);

    private final List<EfeitoEtiqueta> etiquetas = new ArrayList<>();

    private Image imagemMapa;

    // Animação
    private final Timer animator; // controla redraw e animação
    private float globalPhase = 0f;
    private boolean animacaoAtiva = false;

    // Partículas para arestas destacadas (mapa Aresta -> lista Partícula)
    private final Map<Aresta, List<Particle>> particleMap = new HashMap<>();

    // Explosões ativas
    private final List<EfeitoExplosao> explosoes = new ArrayList<>();

    // Informações do comboio em tempo real
    private String cidadeAtual = "";
    private String cidadeProxima = "";
    private int distanciaAtual = 0;
    private int tempoEstimado = 0;
    private int progressoPercurso = 0;
    private boolean mostrarInfoComboio = false;


    public PainelGrafo(List<No> cidades, List<Aresta> conexoes) {
        this.cidades = cidades != null ? cidades : new ArrayList<>();
        this.conexoes = conexoes != null ? conexoes : new ArrayList<>();
        this.caminhoDestacado = null;
        setOpaque(true);
        setPreferredSize(new Dimension(900, 700));

        /*try 
        {
            imagemMapa = new ImageIcon("Image/mapB.jpg").getImage();
        } catch (Exception e) {
            System.err.println("⚠️ Erro ao carregar imagem de fundo: " + e.getMessage());
            imagemMapa = null;
        }*/
        
        configurarEventosRato();

        // Timer suavemente atualizado (~60 FPS)
        animator = new Timer(16, e -> {
            if (animacaoAtiva) {
                globalPhase += 0.02f;
                updateParticles();
            } else {
                globalPhase += 0.002f;
            }

            // Atualiza explosões
            if (!explosoes.isEmpty()) {
                explosoes.forEach(EfeitoExplosao::update);
                explosoes.removeIf(EfeitoExplosao::isDone);
            }

            if (!etiquetas.isEmpty()) {
                etiquetas.forEach(EfeitoEtiqueta::update);
                etiquetas.removeIf(EfeitoEtiqueta::isDone);
            }

            repaint();
        });
        animator.start();
    }

    public void iniciarAnimacao() {
        if (caminhoDestacado == null || caminhoDestacado.isEmpty()) return;
        animacaoAtiva = true;
        // garantir partículas inicializadas para caminhos destacados
        for (Aresta a : caminhoDestacado) ensureParticlesFor(a);
    }

    public void pararAnimacao() {
        animacaoAtiva = false;
    }

    private void ensureParticlesFor(Aresta a) {
        if (a == null) return;
        particleMap.computeIfAbsent(a, k -> {
            ArrayList<Particle> list = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                list.add(new Particle(Math.random()));
            }
            return list;
        });
    }

    private void updateParticles() {
        for (Map.Entry<Aresta, List<Particle>> entry : particleMap.entrySet()) {
            Aresta a = entry.getKey();
            List<Particle> list = entry.getValue();
            if (list == null) continue;
            for (Particle p : list) {
                // velocidade base + variação senoidal para dinamismo
                double speed = 0.0025 + 0.0018 * Math.sin(globalPhase * 2 + p.phase * 6);
                p.t += speed;
                if (p.t > 1.0) p.t -= 1.0;
            }
        }
    }

    public void setFrameParent(JFrame frame) {
        this.frameParent = frame;
    }

    public void setAtualizarComboboxCallback(Runnable callback) {
        this.atualizarComboboxCallback = callback;
    }

    private void configurarEventosRato() {
        // Clique esquerdo para adicionar nó; direito para menu
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    adicionarNo(e.getX(), e.getY());
                } else if (SwingUtilities.isRightMouseButton(e)) {
                    mostrarMenuContexto(e.getX(), e.getY());
                }
            }
        });
    }

    private void adicionarNo(int x, int y) {
        String input = JOptionPane.showInputDialog(
            this,
            "Nome da cidade:",
            "Adicionar Cidade",
            JOptionPane.PLAIN_MESSAGE
        );

        if (input != null && !input.trim().isEmpty()) {
            String nome = input.trim();
            boolean existe = cidades.stream()
                .anyMatch(c -> c.getNome().equalsIgnoreCase(nome));

            if (existe) {
                JOptionPane.showMessageDialog(
                    this,
                    "Já existe uma cidade com esse nome!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            No novaCidade = new No(nome, x, y);
            cidades.add(novaCidade);
            repaint();

            if (atualizarComboboxCallback != null) atualizarComboboxCallback.run();
            actualizarContadores();

            JOptionPane.showMessageDialog(
                this,
                "Cidade '" + nome + "' adicionada com sucesso!",
                "Sucesso",
                JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private void actualizarContadores() {
        if (labelInfo != null) {
            labelInfo.setText(String.format("📍 %d Cidades  •  🔗 %d Conexões", cidades.size(), conexoes.size() / 2));
        }
    }

    private void mostrarMenuContexto(int x, int y) {
        No cidadeClicada = encontrarCidadeNaPosicao(x, y);
        Aresta arestaClicada = encontrarArestaNaPosicao(x, y);

        JPopupMenu menu = new JPopupMenu();
        menu.setBackground(Color.WHITE);
        menu.setBorder(BorderFactory.createLineBorder(new Color(203, 213, 225), 2));

        // 🏙 Menu de cidade
        if (cidadeClicada != null) {
            JMenuItem itemConectar = new JMenuItem("🔗 Conectar com outra cidade");
            itemConectar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            itemConectar.addActionListener(e -> conectarCidade(cidadeClicada));
            menu.add(itemConectar);

            menu.addSeparator();

            JMenuItem itemRemover = new JMenuItem("🗑️ Remover cidade");
            itemRemover.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            itemRemover.setForeground(new Color(239, 68, 68));
            itemRemover.addActionListener(e -> removerCidade(cidadeClicada));
            menu.add(itemRemover);
        }

        // 🧩 Menu de aresta
        if (arestaClicada != null) {
            menu.addSeparator();

            JMenuItem itemAlterar = new JMenuItem("✏️ Alterar peso da aresta");
            itemAlterar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            itemAlterar.addActionListener(e -> alterarPesoAresta(arestaClicada));
            menu.add(itemAlterar);

            JMenuItem itemRemoverAresta = new JMenuItem("🧨 Remover aresta");
            itemRemoverAresta.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            itemRemoverAresta.setForeground(new Color(220, 38, 38));
            itemRemoverAresta.addActionListener(e -> removerArestaComExplosao(arestaClicada));
            menu.add(itemRemoverAresta);
        }

        if (menu.getComponentCount() > 0)
            menu.show(this, x, y);

        actualizarContadores();
    }

    // ✏️ Permite alterar o peso de uma aresta existente
    private void alterarPesoAresta(Aresta a) {
        if (a == null) return;

        No origem = a.getOrigem();
        No destino = a.getDestino();

        String novoPesoStr = JOptionPane.showInputDialog(
            this,
            "Digite o novo peso (distância em km) para a conexão entre\n'" + origem.getNome() + "' e '" + destino.getNome() + "':",
            a.getPeso()
        );

        if (novoPesoStr == null) return; // cancelado

        try {
            int novoPeso = Integer.parseInt(novoPesoStr.trim());
            if (novoPeso <= 0) {
                JOptionPane.showMessageDialog(this, "O peso deve ser maior que zero!", "Erro", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Atualiza peso nas duas direções
            for (Aresta ar : conexoes) {
                if ((ar.getOrigem().equals(origem) && ar.getDestino().equals(destino)) ||
                    (ar.getOrigem().equals(destino) && ar.getDestino().equals(origem))) {
                    ar.setPeso(novoPeso);
                }
            }

            // 💫 Explosão suave no ponto médio para feedback visual
            int mx = (origem.getX() + destino.getX()) / 2;
            int my = (origem.getY() + destino.getY()) / 2;
            explosoes.add(new EfeitoExplosao(mx, my, 30));
            SomExplosao.tocarExplosao();

            // 💬 Etiqueta visual de confirmação
            etiquetas.add(new EfeitoEtiqueta("Peso atualizado!", mx, my - 15));

            repaint();

            JOptionPane.showMessageDialog(this,
                "Peso atualizado para " + novoPeso + " km com sucesso!",
                "Sucesso",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Insira um número válido!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removerArestaComExplosao(Aresta a) {
        if (a == null) return;

        No o = a.getOrigem();
        No d = a.getDestino();
        int mx = (o.getX() + d.getX()) / 2;
        int my = (o.getY() + d.getY()) / 2;

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Remover a conexão entre '" + o.getNome() + "' e '" + d.getNome() + "'?",
            "Confirmar Remoção de Aresta",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            // 💥 Explosão no ponto médio
            explosoes.add(new EfeitoExplosao(mx, my, 50));
            SomExplosao.tocarExplosao(); // 💥 toca som

            // Remove ambas as direções da aresta
            conexoes.removeIf(ar ->
                (ar.getOrigem().equals(o) && ar.getDestino().equals(d)) ||
                (ar.getOrigem().equals(d) && ar.getDestino().equals(o))
            );

            if (caminhoDestacado != null) {
                caminhoDestacado.removeIf(ar ->
                    (ar.getOrigem().equals(o) && ar.getDestino().equals(d)) ||
                    (ar.getOrigem().equals(d) && ar.getDestino().equals(o))
                );
            }

            repaint();
            if (atualizarComboboxCallback != null) atualizarComboboxCallback.run();

            JOptionPane.showMessageDialog(this, "Aresta removida com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private Aresta encontrarArestaNaPosicao(int x, int y) {
        final double tolerancia = 6.0; // margem de clique
        Point2D p = new Point2D.Double(x, y);

        for (Aresta a : conexoes) {
            No o = a.getOrigem();
            No d = a.getDestino();
            if (o == null || d == null) continue;

            Line2D linha = new Line2D.Double(o.getX(), o.getY(), d.getX(), d.getY());
            if (linha.ptSegDist(p) <= tolerancia) {
                return a;
            }
        }
        return null;
}

    private No encontrarCidadeNaPosicao(int x, int y) {
        int raio = 18;
        for (No cidade : cidades) {
            int dx = x - cidade.getX();
            int dy = y - cidade.getY();
            double distancia = Math.sqrt(dx * dx + dy * dy);
            if (distancia <= raio) return cidade;
        }
        return null;
    }

    private void conectarCidade(No origem) {
        JDialog dialog = new JDialog(frameParent, "Conectar Cidade", true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setSize(420, 260);
        dialog.setLocationRelativeTo(this);

        JPanel painelConteudo = new JPanel();
        painelConteudo.setLayout(new BoxLayout(painelConteudo, BoxLayout.Y_AXIS));
        painelConteudo.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        painelConteudo.setBackground(Color.BLACK);

        JLabel labelOrigem = new JLabel("Origem: " + origem.getNome());
        labelOrigem.setFont(new Font("Segoe UI", Font.BOLD, 14));
        labelOrigem.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelConteudo.add(labelOrigem);
        painelConteudo.add(Box.createRigidArea(new Dimension(0, 15)));

        JLabel labelDestino = new JLabel("Selecionar destino:");
        labelDestino.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        labelDestino.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelConteudo.add(labelDestino);
        painelConteudo.add(Box.createRigidArea(new Dimension(0, 5)));

        JComboBox<String> comboDestino = new JComboBox<>();
        for (No cidade : cidades) if (!cidade.equals(origem)) comboDestino.addItem(cidade.getNome());
        comboDestino.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));
        comboDestino.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelConteudo.add(comboDestino);
        painelConteudo.add(Box.createRigidArea(new Dimension(0, 15)));

        JLabel labelPeso = new JLabel("Distância (km):");
        labelPeso.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        labelPeso.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelConteudo.add(labelPeso);
        painelConteudo.add(Box.createRigidArea(new Dimension(0, 5)));

        JTextField campoPeso = new JTextField();
        campoPeso.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));
        campoPeso.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelConteudo.add(campoPeso);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        painelBotoes.setBackground(Color.BLACK);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(e -> dialog.dispose());

        JButton btnConectar = new JButton("Conectar");
        btnConectar.setBackground(new Color(99, 102, 241));
        btnConectar.setForeground(Color.black);
        btnConectar.addActionListener(e -> {
            try {
                String nomeDestino = (String) comboDestino.getSelectedItem();
                int peso = Integer.parseInt(campoPeso.getText().trim());
                if (peso <= 0) {
                    JOptionPane.showMessageDialog(dialog, "A distância deve ser maior que zero!", "Erro", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                No destino = cidades.stream().filter(c -> c.getNome().equals(nomeDestino)).findFirst().orElse(null);
                if (destino != null) {
                    boolean jaExiste = conexoes.stream().anyMatch(a -> (a.getOrigem().equals(origem) && a.getDestino().equals(destino)) || (a.getOrigem().equals(destino) && a.getDestino().equals(origem)));
                    if (jaExiste) {
                        JOptionPane.showMessageDialog(dialog, "Já existe uma conexão entre estas cidades!", "Erro", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    conexoes.add(new Aresta(origem, destino, peso));
                    conexoes.add(new Aresta(destino, origem, peso));
                    repaint();
                    dialog.dispose();
                    JOptionPane.showMessageDialog(this, "Conexão criada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Por favor, insira um número válido para a distância!", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        painelBotoes.add(btnCancelar);
        painelBotoes.add(btnConectar);

        dialog.add(painelConteudo, BorderLayout.CENTER);
        dialog.add(painelBotoes, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private void removerCidade(No cidade) {
        int confirmacao = JOptionPane.showConfirmDialog(
            this,
            "Remover a cidade '" + cidade.getNome() + "' e todas as suas conexões?",
            "Confirmar Remoção",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirmacao == JOptionPane.YES_OPTION) {
            // 💥 adiciona explosão antes da remoção
            explosoes.add(new EfeitoExplosao(cidade.getX(), cidade.getY(), 60));
            SomExplosao.tocarExplosao(); // 💥 toca som

            conexoes.removeIf(a -> a.getOrigem().equals(cidade) || a.getDestino().equals(cidade));
            cidades.remove(cidade);

            if (caminhoDestacado != null) {
                caminhoDestacado.removeIf(a -> a.getOrigem().equals(cidade) || a.getDestino().equals(cidade));
            }

            repaint();

            if (atualizarComboboxCallback != null) atualizarComboboxCallback.run();

            JOptionPane.showMessageDialog(this, "Cidade removida com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        }
    }


    public void setCaminhoDestacado(List<Aresta> caminho) {
        this.caminhoDestacado = caminho;
        // inicializar partículas apenas para as arestas do caminho
        particleMap.keySet().removeIf(a -> caminho == null || !caminho.contains(a));
        if (caminho != null) {
            for (Aresta a : caminho) ensureParticlesFor(a);
        }
        repaint();
    }

    /**
     * Atualiza as informações do comboio em tempo real
     * @param cidadeOrigem Cidade atual
     * @param cidadeDestino Próxima cidade
     * @param distancia Distância em km
     * @param progresso Progresso do percurso total em %
     */
    public void atualizarInfoComboio(String cidadeOrigem, String cidadeDestino, int distancia, int progresso) {
        this.cidadeAtual = cidadeOrigem;
        this.cidadeProxima = cidadeDestino;
        this.distanciaAtual = distancia;
        this.tempoEstimado = distancia / 50; // Conversão: 50 km/dia (mesma lógica do ConversorTempo)
        this.progressoPercurso = progresso;
        this.mostrarInfoComboio = true;
        repaint();
    }

    /**
     * Esconde o painel de informações do comboio
     */
    public void esconderInfoComboio() {
        this.mostrarInfoComboio = false;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        if (cidades == null || conexoes == null) {
            desenharMensagemErro(g2d, "Dados não inicializados");
            // ✏️ Desenhar etiquetas animadas
            for (EfeitoEtiqueta et : etiquetas) {
                et.draw(g2d);
            }
            g2d.dispose();
            return;
        }

        // --- fundo animado ---
        desenharFundoAnimado(g2d);

        if (cidades.isEmpty()) {
            desenharMensagemErro(g2d, "Nenhuma cidade cadastrada");
            g2d.dispose();
            return;
        }

        // desenhar arestas (não destacadas em linhas simples)
        desenharArestas(g2d);

        // desenhar partículas e curvas apenas para as destacadas
        desenharArestasDestacadasAnimadas(g2d);

        // desenhar nós por cima
        desenharNos(g2d);

        // se houver alguma integração com animador externo
        if (frameParent instanceof PainelPrincipal principal) {
            try {
                AnimadorComboio animador = principal.getAnimadorComboio();
                if (animador != null) animador.desenharComboio(g2d);
            } catch (Throwable ignored) {}
        }

        // 💥 desenhar explosões (logo antes de encerrar o método)
        for (EfeitoExplosao exp : explosoes) {
            exp.draw(g2d);
        }

        // 🚂 desenhar painel de informações do comboio no topo
        if (mostrarInfoComboio) {
            desenharPainelInfoComboio(g2d);
        }

        g2d.dispose();
    }


    private void desenharFundoAnimado(Graphics2D g2d) {
        int w = getWidth();
        int h = getHeight();

        // 🗺️ Desenha imagem do mapa de fundo (ajustada ao painel)
        if (imagemMapa != null) {
            g2d.drawImage(imagemMapa, 0, 0, w, h, this);
        } else {
            // Caso não haja imagem, usa o gradiente animado padrão
            float phase = globalPhase;
            float offset = (float) Math.sin(phase * 0.6) * 0.18f;
            Color top = blend(COR_FUNDO_A.brighter(), COR_FUNDO_B, 0.45f + offset);
            Color bottom = blend(COR_FUNDO_B, COR_FUNDO_A.darker(), 0.25f - offset);
            GradientPaint gp = new GradientPaint(0, 0, top, 0, h, bottom);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
        }

        // ✨ Brilho/ruído leve por cima da imagem
        Composite old = g2d.getComposite();
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.035f));
        g2d.setColor(Color.black);
        int dots = 40;
        for (int i = 0; i < dots; i++) {
            int x = (int) ((Math.sin(globalPhase * (i + 3)) * 0.5 + 0.5) * w);
            int y = (int) ((Math.cos(globalPhase * (i + 5)) * 0.5 + 0.5) * h);
            g2d.fillRect(x, y, 1, 1);
        }
        g2d.setComposite(old);
    }


    private void desenharArestas(Graphics2D g2d) {
        g2d.setStroke(new BasicStroke(2.0f));
        Set<String> arestasDesenhadas = new HashSet<>();

        for (Aresta aresta : conexoes) {
            if (aresta == null) continue;
            No origem = aresta.getOrigem();
            No destino = aresta.getDestino();
            if (origem == null || destino == null) continue;

            String chave = criarChaveAresta(origem, destino);
            if (arestasDesenhadas.contains(chave)) continue;
            arestasDesenhadas.add(chave);

            boolean destacada = estaDestacada(aresta);

            if (destacada) {
                // desenhamos curvas e partículas separadamente
                // para manter a ordem visual (partículas por cima da curva)
                // mas aqui desenhamos uma base suave para a curva
                QuadCurve2D q = criarQuad(origem, destino, 0);
                Stroke old = g2d.getStroke();
                g2d.setStroke(new BasicStroke(3.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                // glow base
                g2d.setColor(new Color(30, 90, 160, 80));
                g2d.draw(q);
                // linha principal (sutil)
                g2d.setColor(new Color(80, 170, 255, 160));
                g2d.draw(q);
                g2d.setStroke(old);

                // peso desenhado também, com destaque
                desenharPesoAresta(g2d, origem, destino, aresta.getPeso(), true);
            } else {
                // aresta normal (reta)
                g2d.setStroke(new BasicStroke(2.0f));
                g2d.setColor(COR_ARESTA_NORMAL);
                g2d.drawLine(origem.getX(), origem.getY(), destino.getX(), destino.getY());
                desenharPesoAresta(g2d, origem, destino, aresta.getPeso(), false);
            }
        }
    }

    private void desenharArestasDestacadasAnimadas(Graphics2D g2d) {
        if (caminhoDestacado == null || caminhoDestacado.isEmpty()) return;

        for (Aresta aresta : caminhoDestacado) {
            if (aresta == null) continue;
            No origem = aresta.getOrigem();
            No destino = aresta.getDestino();
            if (origem == null || destino == null) continue;

            // curva base (control point calculado automaticamente para arco suave)
            QuadCurve2D q = criarQuad(origem, destino, 0);

            // desenhar brilho animado seguindo curva (gradiente along path simulated)
            Stroke oldS = g2d.getStroke();
            g2d.setStroke(new BasicStroke(3.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

            // desenha leve halo
            g2d.setColor(new Color(255, 220, 120, 60));
            g2d.draw(q);

            // desenha principal com cor pulsante azul->amarelo
            float mix = (float) ((Math.sin(globalPhase * 2.2) + 1) / 2.0);
            Color col = lerp(new Color(80, 200, 255, 220), new Color(255, 230, 110, 220), mix);
            g2d.setColor(col);
            g2d.draw(q);
            g2d.setStroke(oldS);

            // partículas contínuas ao longo da curva
            List<Particle> plist = particleMap.get(aresta);
            if (plist != null) {
                for (Particle p : plist) {
                    Point2D pt = pontoQuad(q, p.t);
                    float size = (float) (3.5 + 2.5 * Math.sin(globalPhase * 3 + p.phase * 6));
                    float alpha = 0.9f;
                    Color c = lerp(new Color(120, 220, 255, (int) (230 * alpha)), new Color(255, 210, 120, (int) (230 * alpha)), (float) ((Math.sin(globalPhase * 3 + p.phase * 4) + 1) / 2.0));
                    Composite old = g2d.getComposite();
                    g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.95f));
                    g2d.setColor(c);
                    g2d.fill(new Ellipse2D.Double(pt.getX() - size / 2, pt.getY() - size / 2, size, size));
                    g2d.setComposite(old);
                }
            }
        }
    }

    private QuadCurve2D criarQuad(No origem, No destino, double offsetX) {
        double x0 = origem.getX();
        double y0 = origem.getY();
        double x2 = destino.getX();
        double y2 = destino.getY();
        double mx = (x0 + x2) / 2.0 + offsetX;
        double my = (y0 + y2) / 2.0 - 60; // control point acima para arco
        return new QuadCurve2D.Double(x0, y0, mx, my, x2, y2);
    }

    private Point2D pontoQuad(QuadCurve2D q, double t) {
        // fórmula quadrática paramétrica
        double x0 = q.getX1();
        double y0 = q.getY1();
        double cx = q.getCtrlX();
        double cy = q.getCtrlY();
        double x2 = q.getX2();
        double y2 = q.getY2();
        double x = (1 - t) * (1 - t) * x0 + 2 * (1 - t) * t * cx + t * t * x2;
        double y = (1 - t) * (1 - t) * y0 + 2 * (1 - t) * t * cy + t * t * y2;
        return new Point2D.Double(x, y);
    }

    private void desenharPesoAresta(Graphics2D g2d, No origem, No destino, int peso, boolean destacada) {
        int midX = (origem.getX() + destino.getX()) / 2;
        int midY = (origem.getY() + destino.getY()) / 2;
        String textoPeso = peso + "km";
        FontMetrics fm = g2d.getFontMetrics();
        int larguraTexto = fm.stringWidth(textoPeso);
        int alturaTexto = fm.getHeight();
        int padding = 6;

        // caixa semi-transparente
        g2d.setColor(destacada ? new Color(255, 230, 120, 220) : new Color(255, 255, 255, 160));
        g2d.fillRoundRect(midX - larguraTexto / 2 - padding, midY - alturaTexto / 2 - padding / 2, larguraTexto + padding * 2, alturaTexto, 8, 8);

        g2d.setColor(destacada ? new Color(60, 90, 140) : new Color(203, 213, 225));
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawRoundRect(midX - larguraTexto / 2 - padding, midY - alturaTexto / 2 - padding / 2, larguraTexto + padding * 2, alturaTexto, 8, 8);

        g2d.setFont(new Font("Segoe UI", Font.BOLD, 11));
        g2d.setColor(destacada ? new Color(20, 30, 50) : COR_TEXTO_PESO);
        g2d.drawString(textoPeso, midX - larguraTexto / 2, midY + alturaTexto / 4);
    }

    private void desenharNos(Graphics2D g2d) {
        for (No cidade : cidades) {
            if (cidade == null) continue;
            boolean destacada = noEstaDestacado(cidade);
            int raio = destacada ? 20 : 16;

            // sombra projetada
            Composite oldComp = g2d.getComposite();
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.22f));
            double shadowOffset = 8 + 2 * Math.sin(globalPhase * 1.2);
            Ellipse2D shadow = new Ellipse2D.Double(cidade.getX() - raio - 3, cidade.getY() + shadowOffset, (raio + 3) * 2, raio);
            g2d.setColor(new Color(6, 20, 40));
            g2d.fill(shadow);
            g2d.setComposite(oldComp);

            // gradiente radial para efeito 3D
            Point2D center = new Point2D.Float(cidade.getX(), cidade.getY());
            float fr = raio;
            Color deep = new Color(2, 60, 140);
            Color mid = new Color(20, 140, 220);
            Color glow = COR_NO_DESTAQUE;
            RadialGradientPaint rg = new RadialGradientPaint(center, fr, new float[]{0f, 0.6f, 1f}, new Color[]{glow, mid, deep});
            Paint old = g2d.getPaint();
            g2d.setPaint(rg);
            g2d.fillOval(cidade.getX() - raio, cidade.getY() - raio, raio * 2, raio * 2);
            g2d.setPaint(old);


            // contorno
            g2d.setColor(new Color(200, 230, 255, destacada ? 200 : 180));
            g2d.setStroke(new BasicStroke(2.5f));
            g2d.drawOval(cidade.getX() - raio, cidade.getY() - raio, raio * 2, raio * 2);

            // nome abaixo como antes
            desenharNomeCidade(g2d, cidade, destacada);
        }
    }

    private void desenharNomeCidade(Graphics2D g2d, No cidade, boolean destacada) {
        String nome = cidade.getNome();
        g2d.setFont(new Font("Segoe UI", Font.BOLD, destacada ? 13 : 12));
        FontMetrics fm = g2d.getFontMetrics();
        int larguraTexto = fm.stringWidth(nome);
        int alturaTexto = fm.getHeight();

        int textX = cidade.getX() - larguraTexto / 2;
        int textY = cidade.getY() + 30;

        int padding = 6;
        g2d.setColor(new Color(255, 255, 255, 100));
        g2d.fillRoundRect(textX - padding, textY - alturaTexto + 4, larguraTexto + padding * 2, alturaTexto + 2, 6, 6);

        g2d.setColor(destacada ? new Color(60, 90, 140) : new Color(203, 213, 225));
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawRoundRect(textX - padding, textY - alturaTexto + 4, larguraTexto + padding * 2, alturaTexto + 2, 6, 6);

        g2d.setColor(destacada ? new Color(20, 30, 50) : COR_TEXTO);
        g2d.drawString(nome, textX, textY);
    }

    private boolean estaDestacada(Aresta aresta) {
        if (caminhoDestacado == null || caminhoDestacado.isEmpty()) return false;
        for (Aresta d : caminhoDestacado) {
            if (arestasIguais(aresta, d)) return true;
        }
        return false;
    }

    private boolean noEstaDestacado(No cidade) {
        if (caminhoDestacado == null || caminhoDestacado.isEmpty()) return false;
        for (Aresta a : caminhoDestacado) {
            if (a == null) continue;
            No o = a.getOrigem();
            No d = a.getDestino();
            if ((o != null && o.equals(cidade)) || (d != null && d.equals(cidade))) return true;
        }
        return false;
    }

    private boolean arestasIguais(Aresta a1, Aresta a2) {
        if (a1 == null || a2 == null) return false;
        No o1 = a1.getOrigem();
        No d1 = a1.getDestino();
        No o2 = a2.getOrigem();
        No d2 = a2.getDestino();
        if (o1 == null || d1 == null || o2 == null || d2 == null) return false;
        return (o1.equals(o2) && d1.equals(d2)) || (o1.equals(d2) && d1.equals(o2));
    }

    private String criarChaveAresta(No n1, No n2) {
        if (n1 == null || n2 == null) return "";
        String nome1 = n1.getNome();
        String nome2 = n2.getNome();
        return nome1.compareTo(nome2) < 0 ? nome1 + "-" + nome2 : nome2 + "-" + nome1;
    }

    private void desenharMensagemErro(Graphics2D g2d, String mensagem) {
        g2d.setColor(new Color(255, 120, 120));
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 16));
        FontMetrics fm = g2d.getFontMetrics();
        int x = (getWidth() - fm.stringWidth(mensagem)) / 2;
        int y = getHeight() / 2;
        g2d.drawString(mensagem, x, y);
    }

    /**
     * Desenha o painel de informações do comboio no topo do mapa
     */
    private void desenharPainelInfoComboio(Graphics2D g2d) {
        int w = getWidth();
        int panelHeight = 90;
        int panelWidth = Math.min(700, w - 40);
        int panelX = (w - panelWidth) / 2;
        int panelY = 15;

        // Fundo do painel com gradiente
        GradientPaint gradient = new GradientPaint(
            panelX, panelY,
            new Color(15, 30, 60, 240),
            panelX, panelY + panelHeight,
            new Color(30, 50, 90, 240)
        );
        g2d.setPaint(gradient);
        g2d.fillRoundRect(panelX, panelY, panelWidth, panelHeight, 15, 15);

        // Borda brilhante
        g2d.setColor(new Color(80, 170, 255, 200));
        g2d.setStroke(new BasicStroke(2.5f));
        g2d.drawRoundRect(panelX, panelY, panelWidth, panelHeight, 15, 15);

        // Informações
        int textX = panelX + 20;
        int textY = panelY + 25;

        // Linha 1: Origem → Destino
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 16));
        g2d.setColor(new Color(255, 215, 80));
        String rota = cidadeAtual + " → " + cidadeProxima;
        g2d.drawString(rota, textX, textY);

        // Linha 2: Distância e Tempo
        textY += 25;
        g2d.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        g2d.setColor(new Color(200, 220, 255));
        String info = String.format("📏 Distância: %d km  •  ⏱️ Tempo: %d dias", distanciaAtual, tempoEstimado);
        g2d.drawString(info, textX, textY);

        // Linha 3: Barra de progresso
        textY += 25;
        int progressBarWidth = panelWidth - 40;
        int progressBarHeight = 12;
        int progressBarX = panelX + 20;
        int progressBarY = textY - 8;

        // Fundo da barra
        g2d.setColor(new Color(40, 60, 100, 200));
        g2d.fillRoundRect(progressBarX, progressBarY, progressBarWidth, progressBarHeight, 6, 6);

        // Progresso preenchido
        int progressFilled = (progressBarWidth * progressoPercurso) / 100;
        GradientPaint progressGradient = new GradientPaint(
            progressBarX, progressBarY,
            new Color(80, 200, 255),
            progressBarX + progressFilled, progressBarY,
            new Color(120, 220, 120)
        );
        g2d.setPaint(progressGradient);
        g2d.fillRoundRect(progressBarX, progressBarY, progressFilled, progressBarHeight, 6, 6);

        // Borda da barra
        g2d.setColor(new Color(80, 170, 255, 150));
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawRoundRect(progressBarX, progressBarY, progressBarWidth, progressBarHeight, 6, 6);

        // Texto de progresso
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 11));
        g2d.setColor(new Color(255, 255, 255));
        String progressText = progressoPercurso + "%";
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(progressText);
        g2d.drawString(progressText, progressBarX + progressBarWidth + 8, progressBarY + progressBarHeight - 2);
    }

    private static Color lerp(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (a.getRed() * (1 - t) + b.getRed() * t);
        int g = (int) (a.getGreen() * (1 - t) + b.getGreen() * t);
        int bl = (int) (a.getBlue() * (1 - t) + b.getBlue() * t);
        int al = (int) (a.getAlpha() * (1 - t) + b.getAlpha() * t);
        return new Color(r, g, bl, al);
    }

    private static Color blend(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (a.getRed() * (1 - t) + b.getRed() * t);
        int g = (int) (a.getGreen() * (1 - t) + b.getGreen() * t);
        int bl = (int) (a.getBlue() * (1 - t) + b.getBlue() * t);
        return new Color(r, g, bl);
    }

    // Partícula simples de fluxo
    private static class Particle {
        double t; // posição [0..1]
        double phase; // fase aleatória
        Particle(double phase) { this.phase = phase; this.t = Math.random(); }
    }
}
class SomExplosao {
    // Gera dinamicamente um som de explosão curto (sem precisar de ficheiro)
    public static void tocarExplosao() {
        new Thread(() -> {
            try {
                int sampleRate = 44100;
                int durationMs = 450;
                byte[] data = new byte[(int) (sampleRate * durationMs / 1000.0)];
                double freq = 60.0;
                double decay = 0.0025;

                for (int i = 0; i < data.length; i++) {
                    double t = i / (double) sampleRate;
                    // mistura de ruído + oscilação baixa
                    double noise = (Math.random() * 2 - 1);
                    double wave = Math.sin(2 * Math.PI * freq * t);
                    double sample = (noise * 0.6 + wave * 0.4) * Math.exp(-decay * i);
                    data[i] = (byte) (sample * 127);
                }

                AudioFormat format = new AudioFormat(sampleRate, 8, 1, true, false);
                Clip clip = AudioSystem.getClip();
                clip.open(format, data, 0, data.length);
                clip.start();
            } catch (Exception e) {
                System.err.println("⚠️ Erro ao tocar som de explosão: " + e.getMessage());
            }
        }).start();
    }
}

// 💬 Efeito temporário de etiqueta animada (fade e escala)
class EfeitoEtiqueta {
    private final String texto;
    private final int x, y;
    private float alpha = 1f;
    private float escala = 1f;
    private int tempo = 0;

    public EfeitoEtiqueta(String texto, int x, int y) {
        this.texto = texto;
        this.x = x;
        this.y = y;
    }

    public void update() {
        tempo++;
        // Escala suave e fade
        escala = 1f + 0.2f * (float) Math.sin(Math.min(tempo, 25) / 25.0 * Math.PI);
        alpha -= 0.02f;
        if (alpha < 0f) alpha = 0f;
    }

    public boolean isDone() {
        return alpha <= 0f;
    }

    public void draw(Graphics2D g2d) {
        if (alpha <= 0f) return;

        Font oldFont = g2d.getFont();
        Composite oldComp = g2d.getComposite();
        g2d.setFont(new Font("Segoe UI", Font.BOLD, (int) (14 * escala)));
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));

        FontMetrics fm = g2d.getFontMetrics();
        int largura = fm.stringWidth(texto);
        int altura = fm.getHeight();

        // Fundo levemente translúcido
        g2d.setColor(new Color(255, 230, 130, 180));
        g2d.fillRoundRect(x - largura / 2 - 10, y - altura, largura + 20, altura + 6, 12, 12);

        // Texto com sombra
        g2d.setColor(new Color(30, 30, 30));
        g2d.drawString(texto, x - largura / 2, y + 4);

        g2d.setFont(oldFont);
        g2d.setComposite(oldComp);
    }
}
