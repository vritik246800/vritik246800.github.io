package algoritms;

import models.*;
import java.util.*;

public class Dijkstra
{
    // ... [NoDistancia class continua o mesmo] ...
    private class NoDistancia implements Comparable<NoDistancia> {
        No no;
        int distancia;
        public NoDistancia(No no, int distancia) {
            this.no = no;
            this.distancia = distancia;
        }
        @Override
        public int compareTo(NoDistancia outro) {
            return Integer.compare(this.distancia, outro.distancia);
        }
    }

    // Retorna ResultadoDijkstra
    public ResultadoDijkstra executar(Grafo g, No origem, No destino) {

        // 1. Inicialização
        Map<No, Integer> distancias = new HashMap<>();
        Map<No, No> predecessores = new HashMap<>();
        PriorityQueue<NoDistancia> pq = new PriorityQueue<>();

        // Inicializa distâncias
        for (No no : g.getNosOrdenados()) {
            distancias.put(no, Integer.MAX_VALUE);
            predecessores.put(no, null);
        }

        distancias.put(origem, 0);
        pq.add(new NoDistancia(origem, 0));

        // 2. Processamento (lógica de Dijkstra não muda)
        while (!pq.isEmpty()) {
            NoDistancia atual = pq.poll();
            No u = atual.no;
            int dist_u = atual.distancia;

            if (dist_u > distancias.get(u)) continue;
            if (u.equals(destino)) break; // Otimização

            List<Aresta> arestas_u = g.getListasAdj().get(u.getNome());
            if (arestas_u == null) continue;

            for (Aresta aresta : arestas_u) {
                No v = aresta.getDestino();
                int peso = aresta.getPeso();
                // Verifica se u e v são o mesmo nó (auto-loop, se existisse e fosse 0)
                if (u.equals(v)) continue;

                int novaDistancia = dist_u + peso;

                if (novaDistancia < distancias.get(v)) {
                    // Prevenção de overflow se peso for muito grande, embora improvável com int
                    if (novaDistancia < 0) novaDistancia = Integer.MAX_VALUE;

                    distancias.put(v, novaDistancia);
                    predecessores.put(v, u);
                    pq.add(new NoDistancia(v, novaDistancia));
                }
            }
        }

        // 3. Reconstrução do Caminho e Resultado
        return reconstruirCaminho(origem, destino, distancias, predecessores);
    }

    // Atualizado para retornar ResultadoDijkstra
    private ResultadoDijkstra reconstruirCaminho(No origem, No destino, Map<No, Integer> distancias, Map<No, No> predecessores) {

        Integer custo = distancias.get(destino);

        // Inalcançável (custo MAX_VALUE)
        if (custo == null || custo == Integer.MAX_VALUE) {
            return new ResultadoDijkstra(null, -1);
        }

        List<No> caminho = new LinkedList<>();
        No passo = destino;
        while (passo != null) {
            caminho.add(0, passo);
            if (passo.equals(origem)) break;
            passo = predecessores.get(passo);
        }

        // Deve sempre ser verdadeiro se o destino for alcançável e as estruturas estiverem corretas.
        // Se o caminho não começar na origem, algo correu mal ou o passo inicial é inalcançável.
        if (caminho.isEmpty() || !caminho.get(0).equals(origem)) {
            return new ResultadoDijkstra(null, -1);
        }


        return new ResultadoDijkstra(caminho, custo);
    }
}