package algoritms;

import java.util.*;
import models.*;

public class BFS {
	public List<No> executar(Grafo g, No inicio) 
	{
		// Retorna ordem de visita em largura
		List<No> ordem = new ArrayList<>();
		Queue<No> fila = new LinkedList<>();
		Set<String> visitados = new HashSet<>();

		fila.offer(inicio);
		visitados.add(inicio.getNome());

		while (!fila.isEmpty()) {
			No atual = fila.poll();
			ordem.add(atual);

			ArrayList<Aresta> vizinhos = g.getListasAdj().get(atual.getNome());
			if (vizinhos != null) {
				for (Aresta a : vizinhos) {
					No vizinho = a.getDestino();
					if (!visitados.contains(vizinho.getNome())) {
						fila.offer(vizinho);
						visitados.add(vizinho.getNome());
					}
				}
			}
		}
		return ordem;
	}
}
