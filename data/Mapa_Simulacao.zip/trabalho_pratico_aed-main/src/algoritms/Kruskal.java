package algoritms;

import models.Aresta;
import models.Grafo;
import models.No;

import java.util.*;

public class Kruskal {
    public List<Aresta> executar(Grafo g) {
        List<Aresta> mst = new ArrayList<>();
        
        // Coletar arestas únicas usando nomes dos nós
        Set<String> edgeKeys = new HashSet<>();
        List<Aresta> allEdges = new ArrayList<>();
        for (String nome : g.getListasAdj().keySet()) {
            for (Aresta a : g.getListasAdj().get(nome)) {
                String nomeOrigem = a.getOrigem().getNome();
                String nomeDestino = a.getDestino().getNome();
                String[] nomes = {nomeOrigem, nomeDestino};
                Arrays.sort(nomes); // Ordena alfabeticamente
                String key = nomes[0] + "-" + nomes[1];
                if (!edgeKeys.contains(key)) {
                    edgeKeys.add(key);
                    allEdges.add(a);
                }
            }
        }
        
        // Ordenar por peso
        allEdges.sort(Comparator.comparingInt(Aresta::getPeso));
        
        // Union-Find com tamanho baseado em nosOrdenados
        int n = g.getNosOrdenados().size();
        UnionFind uf = new UnionFind(n);
        
        // Mapear No para índice
        Map<No, Integer> nodeToIndex = new HashMap<>();
        List<No> nosOrdenados = g.getNosOrdenados();
        for (int i = 0; i < n; i++) {
            nodeToIndex.put(nosOrdenados.get(i), i);
        }
        
        // Adicionar arestas à MST
        for (Aresta a : allEdges) {
            int idxOrigem = nodeToIndex.get(a.getOrigem());
            int idxDestino = nodeToIndex.get(a.getDestino());
            if (uf.find(idxOrigem) != uf.find(idxDestino)) {
                uf.union(idxOrigem, idxDestino);
                mst.add(a);
            }
        }
        
        return mst;
    }
}
