package algoritms;

import models.No;
import java.util.List;
import java.util.LinkedList;

public class ResultadoDijkstra {
    private List<No> caminho;
    private int custo;

    public ResultadoDijkstra(List<No> caminho, int custo) {
        this.caminho = (caminho != null) ? caminho : new LinkedList<>();
        this.custo = custo;
    }

    public List<No> getCaminho() {
        return caminho;
    }

    public int getCusto() {
        return custo;
    }

    public boolean isInalcancavel() {
        return custo == -1 || caminho.isEmpty();
    }

    @Override
    public String toString() {
        String rotaStr = "N/A";
        if (!caminho.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < caminho.size(); i++) {
                sb.append(caminho.get(i).getNome());
                if (i < caminho.size() - 1) {
                    sb.append(" -> ");
                }
            }
            rotaStr = sb.toString();
        }

        return String.format("Caminho: %s\nCusto Total: %d (%s)",
                rotaStr,
                custo,
                (custo != -1 ? util.ConversorTempo.pesoParaTempo(custo) : "Inalcançável"));
    }
}