package algoritms;

import models.No;
import models.Aresta;
import java.util.List;
import java.util.ArrayList;

public class ResultadoTSP {
    private List<No> rota;
    private List<Aresta> arestasPercorridas; // Lista de arestas que formam a rota completa
    private int custoTotal;
    private boolean rotaCompleta; // True se conseguiu retornar ao início

    public ResultadoTSP(List<No> rota, int custoTotal, boolean rotaCompleta) {
        this.rota = (rota != null) ? rota : new ArrayList<>();
        this.custoTotal = custoTotal;
        this.rotaCompleta = rotaCompleta;
        this.arestasPercorridas = new ArrayList<>();
    }

    public List<No> getRota() {
        return rota;
    }

    public List<Aresta> getArestasPercorridas() {
        return arestasPercorridas;
    }

    public void setArestasPercorridas(List<Aresta> arestasPercorridas) {
        this.arestasPercorridas = arestasPercorridas;
    }

    public int getCustoTotal() {
        return custoTotal;
    }

    public boolean isRotaCompleta() {
        return rotaCompleta;
    }

    @Override
    public String toString() {
        String rotaStr = "Rota Vazia";
        if (!rota.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < rota.size(); i++) {
                sb.append(rota.get(i).getNome());
                if (i < rota.size() - 1) {
                    sb.append(" -> ");
                }
            }
            rotaStr = sb.toString();
        }

        return String.format("Rota (%s): %s\nCusto Total: %d (%s)\nRota Circular Fechada: %s",
                (rota.size() > 0 ? rota.get(0).getNome() : "?"),
                rotaStr,
                custoTotal,
                util.ConversorTempo.pesoParaTempo(custoTotal),
                rotaCompleta ? "Sim" : "Não");
    }
}