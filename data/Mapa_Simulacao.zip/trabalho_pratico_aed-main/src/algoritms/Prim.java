package algoritms;

import models.*;

import java.util.*;

public class Prim 
{
    public List<Aresta> executar(Grafo g) 
    {
        List<Aresta> mst = new ArrayList<>();
        if (g.getNosOrdenados().isEmpty()) 
        	return mst;
        
        // Iniciar do primeiro nó (pode ser alterado para parâmetro se necessário)
        No start = g.getNosOrdenados().get(0);
        
        // PriorityQueue para arestas (menor peso primeiro)
        PriorityQueue<Aresta> pq = new PriorityQueue<>(Comparator.comparingInt(Aresta::getPeso));
        
        // Conjunto de visitados
        Set<No> visited = new HashSet<>();
        visited.add(start);
        
        // Adicionar arestas iniciais
        for (Aresta a : g.getListasAdj().get(start.getNome())) {
            pq.add(a);
        }
        
        // Enquanto houver arestas e não todos visitados
        while (!pq.isEmpty() && visited.size() < g.getNosOrdenados().size()) 
        {
            Aresta minEdge = pq.poll();
            No next = minEdge.getDestino();
            
            if (visited.contains(next)) continue; // Já visitado, ignora
            
            // Adicionar à MST
            mst.add(minEdge);
            visited.add(next);
            
            // Adicionar novas arestas
            for (Aresta a : g.getListasAdj().get(next.getNome())) {
                if (!visited.contains(a.getDestino())) {
                    pq.add(a);
                }
            }
        }
        
        return mst;
    }
}