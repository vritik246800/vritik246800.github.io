package algoritms;

import java.util.*;
import models.*;

public class DFS {
	public List<No> executar(Grafo g, No inicio) 
	{
		// Versão iterativa (Stack)
		List<No> ordem = new ArrayList<>();
		Stack<No> pilha = new Stack<>();
		Set<String> visitados = new HashSet<>();

		pilha.push(inicio);
		visitados.add(inicio.getNome());

		while (!pilha.isEmpty()) {
			No atual = pilha.pop();
			ordem.add(atual);

			ArrayList<Aresta> vizinhos = g.getListasAdj().get(atual.getNome());
			if (vizinhos != null) {
				// Percorre vizinhos em ordem reversa para simular recursão
				for (int i = vizinhos.size() - 1; i >= 0; i--) {
					No vizinho = vizinhos.get(i).getDestino();
					if (!visitados.contains(vizinho.getNome())) {
						pilha.push(vizinho);
						visitados.add(vizinho.getNome());
					}
				}
			}
		}
		return ordem;
	}
}
