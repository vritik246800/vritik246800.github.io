package algoritms;

import models.*;
import java.util.*;

public class TSP
{
    private Dijkstra dijkstra;

    public TSP() {
        this.dijkstra = new Dijkstra();
    }

    // Mudar retorno para ResultadoTSP
    public ResultadoTSP vizinhoMaisProximo(Grafo g, No inicio) {

        List<No> rota = new ArrayList<>();
        List<Aresta> arestasPercorridas = new ArrayList<>(); // Lista de arestas que formam a rota
        Set<No> nosVisitados = new HashSet<>();
        int custoTotal = 0;

        No noAtual = inicio;
        rota.add(noAtual);
        nosVisitados.add(noAtual);

        List<No> todosOsNos = g.getNosOrdenados();

        while (nosVisitados.size() < todosOsNos.size()) {

            No proximoNo = null;
            int menorPeso = Integer.MAX_VALUE;
            Aresta arestaEscolhida = null;

            List<Aresta> arestasDoAtual = g.getListasAdj().get(noAtual.getNome());

            // Primeiro: tentar encontrar vizinho direto não visitado
            if (arestasDoAtual != null && !arestasDoAtual.isEmpty()) {
                for (Aresta aresta : arestasDoAtual) {
                    No vizinho = aresta.getDestino();
                    int peso = aresta.getPeso();

                    if (!nosVisitados.contains(vizinho)) {
                        if (peso < menorPeso) {
                            menorPeso = peso;
                            proximoNo = vizinho;
                            arestaEscolhida = aresta;
                        }
                    }
                }
            }

            if (proximoNo != null) {
                // Movimento direto para vizinho mais próximo
                custoTotal += arestaEscolhida.getPeso();
                arestasPercorridas.add(arestaEscolhida);
                noAtual = proximoNo;
                rota.add(noAtual);
                nosVisitados.add(noAtual);
            } else {
                // BACKTRACKING: Não há vizinhos diretos não visitados
                // Usar Dijkstra para encontrar caminho até o nó não visitado mais próximo
                No nosNaoVisitado = encontrarNosNaoVisitadoMaisProximo(g, noAtual, nosVisitados);

                if (nosNaoVisitado == null) {
                    System.err.println("Aviso TSP: Grafo desconexo. Não é possível visitar todos os nós.");
                    break;
                }

                // Calcular caminho com Dijkstra
                ResultadoDijkstra resultado = dijkstra.executar(g, noAtual, nosNaoVisitado);
                List<No> caminhoNos = resultado.getCaminho();

                if (caminhoNos == null || caminhoNos.isEmpty()) {
                    System.err.println("Erro TSP: Não foi possível encontrar caminho para nó não visitado.");
                    break;
                }

                // Converter caminho de nós em arestas
                List<Aresta> caminhoBacktrack = converterCaminhoParaArestas(caminhoNos, g);

                if (caminhoBacktrack == null || caminhoBacktrack.isEmpty()) {
                    System.err.println("Erro TSP: Falha ao converter caminho em arestas.");
                    break;
                }

                // Adicionar todo o caminho de backtracking à rota
                for (Aresta aresta : caminhoBacktrack) {
                    custoTotal += aresta.getPeso();
                    arestasPercorridas.add(aresta);

                    // Adicionar nós intermediários apenas se não estiverem na rota
                    No destino = aresta.getDestino();
                    if (!rota.contains(destino)) {
                        rota.add(destino);
                    }
                }

                noAtual = nosNaoVisitado;
                nosVisitados.add(nosNaoVisitado);
            }
        }

        // FASE DE FECHO DA ROTA (Circularidade)
        boolean rotaCompleta = false;

        // 1. Verificar se todos os nós foram visitados
        if (nosVisitados.size() == todosOsNos.size()) {

            No ultimoNo = noAtual;
            Aresta arestaFecho = null;

            // 2. Tentar encontrar aresta direta de volta ao início
            List<Aresta> arestasUltimo = g.getListasAdj().get(ultimoNo.getNome());
            if (arestasUltimo != null) {
                for (Aresta aresta : arestasUltimo) {
                    if (aresta.getDestino().equals(inicio)) {
                        arestaFecho = aresta;
                        break;
                    }
                }
            }

            if (arestaFecho != null) {
                // Aresta de fecho direta encontrada
                custoTotal += arestaFecho.getPeso();
                arestasPercorridas.add(arestaFecho);
                rota.add(inicio);
                rotaCompleta = true;
            } else {
                // Não há aresta direta: usar Dijkstra para voltar ao início
                ResultadoDijkstra resultadoFecho = dijkstra.executar(g, ultimoNo, inicio);
                List<No> caminhoNosFecho = resultadoFecho.getCaminho();

                if (caminhoNosFecho != null && !caminhoNosFecho.isEmpty()) {
                    // Converter caminho de nós em arestas
                    List<Aresta> caminhoFecho = converterCaminhoParaArestas(caminhoNosFecho, g);

                    if (caminhoFecho != null && !caminhoFecho.isEmpty()) {
                        // Adicionar caminho de retorno
                        for (Aresta aresta : caminhoFecho) {
                            custoTotal += aresta.getPeso();
                            arestasPercorridas.add(aresta);
                        }
                        rota.add(inicio);
                        rotaCompleta = true;
                    } else {
                        System.err.println("Erro TSP: Falha ao converter caminho de fecho em arestas.");
                        rotaCompleta = false;
                    }
                } else {
                    System.err.println("Erro TSP: Não foi possível encontrar caminho de retorno ao início.");
                    rotaCompleta = false;
                }
            }
        }

        // Se a rota não visitou todos os nós (grafo desconexo)
        if (nosVisitados.size() < todosOsNos.size()) {
            rotaCompleta = false;
        }

        ResultadoTSP resultado = new ResultadoTSP(rota, custoTotal, rotaCompleta);
        resultado.setArestasPercorridas(arestasPercorridas); // Guardar lista de arestas para animação
        return resultado;
    }

    /**
     * Encontra o nó não visitado mais próximo usando Dijkstra.
     * Retorna o nó não visitado que tem a menor distância a partir de noAtual.
     */
    private No encontrarNosNaoVisitadoMaisProximo(Grafo g, No noAtual, Set<No> nosVisitados) {
        No maisProximo = null;
        int menorDistancia = Integer.MAX_VALUE;

        for (No candidato : g.getNosOrdenados()) {
            if (!nosVisitados.contains(candidato)) {
                ResultadoDijkstra resultado = dijkstra.executar(g, noAtual, candidato);
                int distancia = resultado.getCusto();

                if (distancia != -1 && distancia < menorDistancia) {
                    menorDistancia = distancia;
                    maisProximo = candidato;
                }
            }
        }

        return maisProximo;
    }

    /**
     * Converte uma lista de nós (caminho) em uma lista de arestas.
     * Para cada par consecutivo de nós, encontra a aresta correspondente no grafo.
     */
    private List<Aresta> converterCaminhoParaArestas(List<No> caminhoNos, Grafo g) {
        if (caminhoNos == null || caminhoNos.size() < 2) {
            return new ArrayList<>();
        }

        List<Aresta> arestas = new ArrayList<>();

        for (int i = 0; i < caminhoNos.size() - 1; i++) {
            No origem = caminhoNos.get(i);
            No destino = caminhoNos.get(i + 1);

            // Procurar aresta entre origem e destino
            List<Aresta> arestasOrigem = g.getListasAdj().get(origem.getNome());

            if (arestasOrigem != null) {
                boolean encontrou = false;
                for (Aresta aresta : arestasOrigem) {
                    if (aresta.getDestino().equals(destino)) {
                        arestas.add(aresta);
                        encontrou = true;
                        break;
                    }
                }

                if (!encontrou) {
                    System.err.println("Erro TSP: Aresta não encontrada entre " + origem.getNome() + " e " + destino.getNome());
                    return null; // Falha na conversão
                }
            } else {
                System.err.println("Erro TSP: Nó " + origem.getNome() + " não tem arestas.");
                return null;
            }
        }

        return arestas;
    }
}