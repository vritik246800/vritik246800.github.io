import models.Grafo;
import models.No;
import java.util.List;
import algoritms.BFS;
import algoritms.DFS;
import util.UtilGrafo;

public class TestGrafo {

public static void main(String[] args) {
        Grafo grafo = new Grafo();

        // Adiciona nós com coordenadas (exemplo aproximado)
        No luhansk = new No("Luhansk", 100, 50);
        No donetsk = new No("Donetsk", 150, 100);
        No zaporizhzhia = new No("Zaporizhzhia", 200, 150);
        No kherson = new No("Kherson", 250, 200);

        grafo.addNo(luhansk);
        grafo.addNo(donetsk);
        grafo.addNo(zaporizhzhia);
        grafo.addNo(kherson);

        // Adiciona arestas com pesos (distâncias em km)
        grafo.addAresta("Luhansk", "Donetsk", 150);
        grafo.addAresta("Luhansk", "Zaporizhzhia", 380);
        grafo.addAresta("Luhansk", "Kherson", 690);
        grafo.addAresta("Donetsk", "Zaporizhzhia", 230);
        grafo.addAresta("Donetsk", "Kherson", 540);
        grafo.addAresta("Zaporizhzhia", "Kherson", 300);

        // Teste adicional: grafo de Königsberg para validação
        Grafo grafoKonigsberg = new Grafo();
        No a = new No("A", 50, 50); // Norte
        No b = new No("B", 50, 150); // Sul
        No c = new No("C", 100, 100); // Ilha
        No d = new No("D", 150, 100); // Leste
        grafoKonigsberg.addNo(a); grafoKonigsberg.addNo(b);
        grafoKonigsberg.addNo(c); grafoKonigsberg.addNo(d);
        grafoKonigsberg.addAresta("A", "C", 1);
        grafoKonigsberg.addAresta("A", "B", 1);
        grafoKonigsberg.addAresta("A", "D", 1);
        grafoKonigsberg.addAresta("B", "D", 1);
        grafoKonigsberg.addAresta("C", "D", 1);

        // Salve para uso posterior
        testarAlgoritmos(grafo, luhansk);
        testarAlgoritmos(grafoKonigsberg, a);
    }

    private static void testarAlgoritmos(Grafo g, No inicio) {
        // Instancia as classes
        BFS bfs = new BFS();
        DFS dfs = new DFS();
        UtilGrafo util = new UtilGrafo();

        // Executa BFS
        List<No> ordemBFS = bfs.executar(g, inicio);
        System.out.println("Ordem BFS a partir de " + inicio.getNome() + ":");
        for (No no : ordemBFS) System.out.print(no.getNome() + " ");
        System.out.println();

        // Executa DFS
        List<No> ordemDFS = dfs.executar(g, inicio);
        System.out.println("Ordem DFS a partir de " + inicio.getNome() + ":");
        for (No no : ordemDFS) System.out.print(no.getNome() + " ");
        System.out.println();

        // Verifica conectividade
        boolean conectado = util.verificarConectividade(g);
        System.out.println("Grafo conectado? " + conectado);

        // Obtém componentes conexas
        List<List<No>> componentes = util.obterComponentesConexas(g);
        System.out.println("Componentes conexas: " + componentes.size());
    }
}
