package util;

public class ConversorTempo 
{
    private static final int MINUTOS_POR_KM = 6;
    
    public static String pesoParaTempo(int peso) 
    {
        int minutos, horas, mins, dias, hrs;
        String resultado;
        
        minutos = peso * MINUTOS_POR_KM;
        
        if (minutos < 60) 
            return minutos + " minutos";
        
        horas = minutos / 60;
        mins = minutos % 60;
        
        if (horas < 24) 
        {
            resultado = horas + "h";
            if (mins > 0) 
                resultado += mins + "m";
            
            return resultado;
        }
        
        dias = horas / 24;
        hrs = horas % 24;
        
        if (dias < 7) 
        {
            resultado = dias + " dia";
            if (dias > 1)
                resultado += "s";
         
            if (hrs > 0)
                resultado += " " + hrs + "h";
            
            return resultado;
        }
        
        int semanas = dias / 7;
        int diasRest = dias % 7;
        
        resultado = semanas + " semana";
        if (semanas > 1) 
            resultado += "s";
        
        if (diasRest > 0)
            resultado += " " + diasRest + "d";
        
        return resultado;
    }
}