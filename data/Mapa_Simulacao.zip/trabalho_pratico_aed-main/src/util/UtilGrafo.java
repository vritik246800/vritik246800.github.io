package util;
import models.*;

import java.util.*;

import algoritms.BFS;

/**
 * Classe utilitária com métodos auxiliares para análise topológica de grafos
 */
public class UtilGrafo
{

    /**
     * Verifica se o grafo é conexo (todos os nós são alcançáveis a partir de qualquer nó)
     * @param g Grafo a ser verificado
     * @return true se o grafo é conexo, false caso contrário
     */
    public static boolean verificarConectividade(Grafo g) {
        if (g.getNosOrdenados().isEmpty()) {
            return true;
        }

        BFS bfs = new BFS();
        No inicial = g.getNosOrdenados().get(0);
        List<No> alcancaveis = bfs.executar(g, inicial);

        return alcancaveis.size() == g.getNosOrdenados().size();
    }

    /**
     * Obtém todas as componentes conexas do grafo
     * @param g Grafo a ser analisado
     * @return Lista de listas, onde cada lista interna representa uma componente conexa
     */
    public static List<List<No>> obterComponentesConexas(Grafo g) {
        List<List<No>> componentes = new ArrayList<>();
        HashSet<String> visitados = new HashSet<>();
        BFS bfs = new BFS();

        for (No no : g.getNosOrdenados()) {
            if (!visitados.contains(no.getNome())) {
                List<No> componente = bfs.executar(g, no);

                for (No noComponente : componente) {
                    visitados.add(noComponente.getNome());
                }

                componentes.add(componente);
            }
        }

        return componentes;
    }

    /**
     * Calcula o grau médio do grafo
     * @param g Grafo a ser analisado
     * @return Grau médio dos nós
     */
    public static double calcularGrauMedio(Grafo g) {
        int totalArestas = 0;
        for (String key : g.getListasAdj().keySet()) {
            totalArestas += g.getListasAdj().get(key).size();
        }
        int numNos = g.getNos().size();
        return numNos == 0 ? 0 : (double) (totalArestas / 2) / numNos;  // /2 pois undirected
    }

    /**
     * Cria uma cópia do grafo sem um nó específico
     */
    private static Grafo copiarGrafoSemNo(Grafo original, No removido) {
        Grafo copia = new Grafo();
        for (No n : original.getNosOrdenados()) {
            if (!n.equals(removido)) {
                copia.addNo(new No(n.getNome(), n.getX(), n.getY()));
            }
        }
        for (String key : original.getListasAdj().keySet()) {
            if (!key.equals(removido.getNome())) {
                for (Aresta a : original.getListasAdj().get(key)) {
                    if (!a.getDestino().equals(removido)) {
                        copia.addAresta(key, a.getDestino().getNome(), a.getPeso());
                    }
                }
            }
        }
        return copia;
    }

    /**
     * Identifica nós críticos (articulação) - nós cuja remoção desconecta o grafo
     * @param g Grafo a ser analisado
     * @return Lista de nós críticos
     */
    public static List<No> identificarNosCriticos(Grafo g) {
        List<No> criticos = new ArrayList<>();
        boolean originalConexo = verificarConectividade(g);

        for (No no : g.getNosOrdenados()) {
            // Cópia do grafo sem o nó
            Grafo copia = copiarGrafoSemNo(g, no);
            boolean conexoSemNo = verificarConectividade(copia);
            if (originalConexo && !conexoSemNo) {
                criticos.add(no);
            }
        }
        return criticos;
    }
}
