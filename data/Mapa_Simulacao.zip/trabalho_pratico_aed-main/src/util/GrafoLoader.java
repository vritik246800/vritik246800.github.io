package util;

import models.*;
import java.io.*;
import java.util.*;

public class GrafoLoader 
{
    public static void carregarNos(Grafo g, String caminhoFicheiro) 
    {
        String linha;
        String nome;
        int x, y;
        StringTokenizer token;
        
        try 
        {
            BufferedReader br = new BufferedReader(new FileReader(caminhoFicheiro));
            linha = br.readLine();
            
            while (linha != null) 
            {
                linha = linha.trim();

                
                token = new StringTokenizer(linha, ";");
                
                nome = token.nextToken();
                x = Integer.parseInt(token.nextToken());
                y = Integer.parseInt(token.nextToken());
                
                g.addNo(new No(nome, x, y));
                
                linha = br.readLine();
            }
            
            br.close();
            
        } catch (FileNotFoundException err404) 
        {
            System.err.println("FALHA AO LOCALIZAR O FICHEIRO DE NÓS!");
        } catch (NumberFormatException errNAN) 
        {
            System.err.println("FORMATO INVÁLIDO NOS DADOS DE NÓS!");
        } catch (IOException errIO) 
        {
            System.err.println("FALHA NAS OPERAÇÕES DE ENTRADA E SAÍDA!");
        }
    }
    
    public static void carregarArestas(Grafo g, String caminhoFicheiro) 
    {
        String linha;
        String origem, destino;
        int peso;
        StringTokenizer token;
        
        try 
        {
            BufferedReader br = new BufferedReader(new FileReader(caminhoFicheiro));
            linha = br.readLine();
            
            while (linha != null) 
            {
                linha = linha.trim();
                
                token = new StringTokenizer(linha, ";");
                
                origem = token.nextToken();
                destino = token.nextToken();
                peso = Integer.parseInt(token.nextToken());
                
                g.addAresta(origem, destino, peso);
                
                linha = br.readLine();
            }
            
            br.close();
            
        } catch (FileNotFoundException err404) 
        {
            System.err.println("FALHA AO LOCALIZAR O FICHEIRO DE NÓS!");
        } catch (NumberFormatException errNAN) 
        {
            System.err.println("FORMATO INVÁLIDO NOS DADOS DE NÓS!");
        } catch (IOException errIO) 
        {
            System.err.println("FALHA NAS OPERAÇÕES DE ENTRADA E SAÍDA!");
        }
    }
    
 
    public static Grafo carregarMapaUcrania() 
    {
        Grafo g = new Grafo();
        
        g.addNo(new No("Kyiv", 330, 240));
        g.addNo(new No("Zhitomyr", 80, 290));
        g.addNo(new No("Kharkiv", 680, 270));
        g.addNo(new No("Odesa", 350, 520));
        g.addNo(new No("Dnipro", 580, 400));
        g.addNo(new No("Donetsk", 750, 420));
        g.addNo(new No("Zaporizhzhya", 620, 450));
        g.addNo(new No("Kherson", 480, 500));
        g.addNo(new No("Sumy", 580, 190));
        g.addNo(new No("Chernihiv", 380, 160));
        g.addNo(new No("Poltava", 550, 290));
        g.addNo(new No("Vinnytsa", 80, 390));
        g.addNo(new No("Mykolaiv", 320, 460));
        g.addNo(new No("Kropyvnitskyi", 400, 400));
        g.addNo(new No("Luhansk", 790, 300));
        
        g.addAresta("Kyiv", "Chernihiv", 140);
        g.addAresta("Kyiv", "Sumy", 330);
        g.addAresta("Kyiv", "Poltava", 340);
        g.addAresta("Kyiv", "Vinnytsa", 570);
        g.addAresta("Kyiv", "Zhitomyr", 340);
        g.addAresta("Chernihiv", "Sumy", 300);
        g.addAresta("Sumy", "Kharkiv", 180);
        g.addAresta("Kharkiv", "Poltava", 145);
        g.addAresta("Kharkiv", "Luhansk", 340);
        g.addAresta("Poltava", "Dnipro", 200);
        g.addAresta("Dnipro", "Zaporizhzhya", 85);
        g.addAresta("Dnipro", "Donetsk", 240);
        g.addAresta("Zaporizhzhya", "Donetsk", 210);
        g.addAresta("Zaporizhzhya", "Kherson", 280);
        g.addAresta("Kherson", "Mykolaiv", 60);
        g.addAresta("Mykolaiv", "Odesa", 130);
        g.addAresta("Mykolaiv", "Vinnytsa", 380);
        g.addAresta("Vinnytsa", "Zhitomyr", 300);
        g.addAresta("Kropyvnitskyi", "Mykolaiv", 60);
        g.addAresta("Kropyvnitskyi", "Dnipro", 70);
        g.addAresta("Kropyvnitskyi", "Vinnytsa", 340);
        g.addAresta("Kropyvnitskyi", "Poltava", 120);
        g.addAresta("Poltava", "Sumy", 90);
        g.addAresta("Dnipro", "Kharkiv", 100);
        g.addAresta("Luhansk", "Kharkiv", 120);
        g.addAresta("Donetsk", "Kharkiv", 150);
        g.addAresta("Luhansk", "Donetsk", 120);
        
        return g;
    }
}
