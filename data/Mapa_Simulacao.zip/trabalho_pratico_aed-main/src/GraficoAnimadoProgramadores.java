import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;

/**
 * GraficoAnimadoProgramadores.java
 *
 * Versão "marcante" com efeito holográfico 3D, arestas curvas (QuadCurve2D),
 * partículas de fluxo animadas que percorrem as curvas, sombras e interação.
 *
 * Compile: javac GraficoAnimadoProgramadores.java
 * Execute:   java GraficoAnimadoProgramadores
 */
public class GraficoAnimadoProgramadores {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Nó dos Programadores");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new GraphPanel());
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}

class GraphPanel extends JPanel implements ActionListener, MouseListener, MouseMotionListener {
    private final java.util.List<Node> nodes = new ArrayList<>();
    private final java.util.List<Edge> edges = new ArrayList<>();
    private final Timer timer;
    private float globalPhase = 0f; // animação global
    private Node hovered = null;
    private Node selected = null;

    public GraphPanel() {
        setPreferredSize(new Dimension(1000, 860));
        setBackground(Color.BLACK);
        addMouseListener(this);
        addMouseMotionListener(this);

        // posições hierárquicas (centralizado)
        int cx = 450;
        Node helder = new Node("Helder Vuca Junior", "20230414", cx, 120, 42);
        Node vritik = new Node("Vritik Valabdas", "20190025", cx, 300, 34);
        Node layza = new Node("Layza Maria Alice Chichava", "20230185", cx - 320, 460, 34);
        Node roan = new Node("Roan Yosky Dos Santos Timane", "20230202", cx, 500, 34);
        Node tamara = new Node("Tamara Tais Arao Fumo", "20230903", cx + 320, 460, 34);

        nodes.add(helder);
        nodes.add(vritik);
        nodes.add(layza);
        nodes.add(roan);
        nodes.add(tamara);

        // edges with control points for smooth curves
        edges.add(new Edge(helder, vritik, 0));
        edges.add(new Edge(vritik, layza, -120));
        edges.add(new Edge(vritik, roan, 0));
        edges.add(new Edge(vritik, tamara, 120));

        timer = new Timer(16, this); // ~60 FPS
        timer.start();

        setToolTipText("");
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        int w = getWidth();
        int h = getHeight();

        // --- fundo dinâmico em gradiente animado ---
        float offset = (float) Math.sin(globalPhase * 0.6) * 0.15f; // -0.15..0.15
        Color c1 = new Color(6, 20, 40);
        Color c2 = new Color(2, 48, 89);
        Color c3 = new Color(3, 8, 20);
        GradientPaint gp = new GradientPaint(0, 0, blend(c1, c2, 0.2f + offset), 0, h, blend(c2, c3, 0.2f - offset));
        g2.setPaint(gp);
        g2.fillRect(0, 0, w, h);

        // leve textura/ruído translúcido (sutileza)
        Composite oldComp = g2.getComposite();
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.04f));
        g2.setColor(Color.WHITE);
        for (int i = 0; i < 60; i++) {
            int x = (int) (Math.random() * w);
            int y = (int) (Math.random() * h);
            g2.fillRect(x, y, 1, 1);
        }
        g2.setComposite(oldComp);

        // cabeçalho holográfico
        drawHeader(g2, w);

        // desenha arestas curvas primeiro (por baixo dos nós)
        for (Edge edge : edges) {
            edge.drawCurve(g2, globalPhase, hovered == edge.from || hovered == edge.to || selected == edge.from || selected == edge.to);
        }

        // partículas de fluxo
        for (Edge edge : edges) edge.drawParticles(g2, globalPhase, hovered == edge.from || hovered == edge.to || selected == edge.from || selected == edge.to);

        // nós (com sombras e efeito 3D)
        for (Node n : nodes) n.draw(g2, globalPhase, n == hovered, n == selected);

        // legenda pequena
        drawFooter(g2, w, h);

        g2.dispose();
    }

    private void drawHeader(Graphics2D g2, int width) {
        String header = "Nó dos Programadores";
        g2.setFont(new Font("Segoe UI", Font.BOLD, 34));
        FontMetrics fm = g2.getFontMetrics();
        int x = (width - fm.stringWidth(header)) / 2;
        int y = 60;

        // sombra azul atrás
        g2.setColor(new Color(0, 60, 120, 120));
        g2.setFont(new Font("Segoe UI", Font.BOLD, 36));
        g2.drawString(header, x + 4, y + 6);

        // texto dourado principal
        g2.setColor(new Color(255, 215, 80));
        g2.setFont(new Font("Segoe UI", Font.BOLD, 34));
        g2.drawString(header, x, y);

        // aura pulsante
        int auraW = 260;
        int auraH = 28;
        float aphase = (float) (0.5f + 0.5f * Math.sin(globalPhase * 2.0));
        Composite old = g2.getComposite();
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.08f + 0.12f * aphase));
        g2.setColor(new Color(255, 200, 60));
        g2.fillRoundRect(x - 10, y - fm.getAscent() + 6, auraW, auraH, 18, 18);
        g2.setComposite(old);
    }

    private void drawFooter(Graphics2D g2, int w, int h) {
        g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g2.setColor(new Color(180, 190, 210, 140));
        g2.drawString("Hover para destacar • Clique para selecionar", 18, h - 18);
    }

    private static Color blend(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (a.getRed() * (1 - t) + b.getRed() * t);
        int g = (int) (a.getGreen() * (1 - t) + b.getGreen() * t);
        int bl = (int) (a.getBlue() * (1 - t) + b.getBlue() * t);
        return new Color(r, g, bl);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        globalPhase += 0.018f;
        repaint();
    }

    // mouse events
    @Override
    public void mouseClicked(MouseEvent e) {
        Node hit = findNode(e.getX(), e.getY());
        if (hit != null) selected = (selected == hit) ? null : hit;
    }

    @Override public void mousePressed(MouseEvent e) {}
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {
        hovered = null;
        setToolTipText("");
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        Node hit = findNode(e.getX(), e.getY());
        if (hit != hovered) {
            hovered = hit;
            if (hovered != null) setToolTipText(hovered.name + " — " + hovered.code);
            else setToolTipText("");
        }
    }

    @Override public void mouseDragged(MouseEvent e) {}

    private Node findNode(int mx, int my) {
        for (Node n : nodes) {
            double dx = mx - n.x;
            double dy = my - n.y;
            if (dx * dx + dy * dy <= n.baseRadius * n.baseRadius) return n;
        }
        return null;
    }

}

class Node {
    static int COUNTER = 0;
    final int id;
    final String name;
    final String code;
    double x, y;
    double baseRadius;

    Node(String name, String code, double x, double y, double radius) {
        this.id = COUNTER++;
        this.name = name;
        this.code = code;
        this.x = x;
        this.y = y;
        this.baseRadius = radius;
    }

    void draw(Graphics2D g2, float phase, boolean hover, boolean selected) {
        // sombra projetada (3D)
        Composite oldComp = g2.getComposite();
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.22f));
        double shadowOffset = 10 + 4 * Math.sin(phase * 1.3 + id);
        Ellipse2D shadow = new Ellipse2D.Double(x - baseRadius - 6, y + shadowOffset, (baseRadius + 6) * 2, (baseRadius / 2));
        g2.setColor(new Color(6, 20, 40));
        g2.fill(shadow);
        g2.setComposite(oldComp);

        // pulsação 3D
        double pulse = 1.0 + (selected ? 0.14 * Math.abs(Math.sin(phase * 2.4 + id)) : 0.06 * Math.sin(phase * 2.0 + id));
        double r = baseRadius * pulse;

        // gradiente radial holográfico (azul -> destaque amarelo no topo)
        Point2D center = new Point2D.Float((float) x, (float) y);
        float radius = (float) r;
        Color deep = new Color(2, 60, 140); // azul profundo
        Color mid = new Color(20, 140, 220); // azul elétrico
        Color glow = new Color(255, 220, 120); // dourado
        RadialGradientPaint rg = new RadialGradientPaint(center, radius, new float[]{0f, 0.65f, 1f}, new Color[]{glow, mid, deep});
        Paint old = g2.getPaint();
        g2.setPaint(rg);
        Ellipse2D circle = new Ellipse2D.Double(x - r, y - r, r * 2, r * 2);
        g2.fill(circle);
        g2.setPaint(old);

        // contorno brilhante
        g2.setColor(new Color(200, 230, 255, hover ? 230 : 150));
        g2.setStroke(new BasicStroke((float) Math.max(2f, baseRadius * 0.08f)));
        g2.draw(circle);

        // nome e código ao lado (claros)
        g2.setFont(new Font("SansSerif", Font.BOLD, 14));
        g2.setColor(new Color(230, 240, 255));
        g2.drawString(name, (int) (x + r + 18), (int) (y - 3));
        g2.setFont(new Font("Monospaced", Font.PLAIN, 12));
        g2.setColor(new Color(255, 230, 120));
        g2.drawString(code, (int) (x + r + 18), (int) (y + 14));
    }
}

class Edge {
    final Node from;
    final Node to;
    final double ctrlOffsetX; // deslocamento para o control point
    final java.util.List<Particle> particles = new ArrayList<>();

    Edge(Node from, Node to, double ctrlOffsetX) {
        this.from = from;
        this.to = to;
        this.ctrlOffsetX = ctrlOffsetX;
        // inicializa algumas partículas com fases distintas
        for (int i = 0; i < 8; i++) particles.add(new Particle(Math.random())) ;
    }

    // calcula ponto da curva quadrática em t [0..1]
    private Point2D bezier(double t) {
        double x0 = from.x, y0 = from.y;
        double x2 = to.x, y2 = to.y;
        double mx = (x0 + x2) / 2.0 + ctrlOffsetX;
        double my = (y0 + y2) / 2.0 - 80; // control point acima para arco
        double x = (1 - t) * (1 - t) * x0 + 2 * (1 - t) * t * mx + t * t * x2;
        double y = (1 - t) * (1 - t) * y0 + 2 * (1 - t) * t * my + t * t * y2;
        return new Point2D.Double(x, y);
    }

    void drawCurve(Graphics2D g2, float phase, boolean highlight) {
        double x0 = from.x, y0 = from.y;
        double x2 = to.x, y2 = to.y;
        double mx = (x0 + x2) / 2.0 + ctrlOffsetX;
        double my = (y0 + y2) / 2.0 - 80;

        QuadCurve2D q = new QuadCurve2D.Double(x0, y0, mx, my, x2, y2);

        // cor base da curva: azul translúcido
        Color base = new Color(60, 170, 230, highlight ? 220 : 140);
        Stroke oldS = g2.getStroke();
        g2.setStroke(new BasicStroke(3.0f + (highlight ? 1.8f : 0f), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        // desenhar leve brilho por baixo
        g2.setColor(new Color(20, 80, 140, 80));
        g2.draw(q);

        g2.setColor(base);
        g2.draw(q);
        g2.setStroke(oldS);
    }

    void drawParticles(Graphics2D g2, float phase, boolean highlight) {
        // partículas percorrem a curva
        for (Particle p : particles) {
            double speed = 0.0025 + 0.0015 * Math.sin(phase * 2 + p.phase * 10);
            if (highlight) speed *= 2.2; // acelera se destaque
            p.t += speed;
            if (p.t > 1.0) p.t = 0.0;

            Point2D pt = bezier(p.t);
            float size = (float) (4.0 + 3.0 * Math.sin(phase * 4 + p.phase * 6));

            // cor alternada azul -> amarelo
            float mix = (float) ((Math.sin(phase * 3 + p.phase * 7) + 1) / 2.0);
            Color c = lerp(new Color(80, 200, 255, 230), new Color(255, 230, 110, 230), mix);

            Composite old = g2.getComposite();
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.95f));
            g2.setColor(c);
            g2.fill(new Ellipse2D.Double(pt.getX() - size / 2, pt.getY() - size / 2, size, size));
            g2.setComposite(old);
        }
    }

    private static Color lerp(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (a.getRed() * (1 - t) + b.getRed() * t);
        int g = (int) (a.getGreen() * (1 - t) + b.getGreen() * t);
        int bl = (int) (a.getBlue() * (1 - t) + b.getBlue() * t);
        int al = (int) (a.getAlpha() * (1 - t) + b.getAlpha() * t);
        return new Color(r, g, bl, al);
    }

    static class Particle {
        double t; // posição ao longo da curva
        double phase; // fase aleatória

        Particle(double phase) {
            this.phase = phase;
            this.t = Math.random();
        }
    }
}