import javax.swing.*;
import java.awt.*;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.Queue;

public class JanelaMonitorizacao extends JFrame {
    private JLabel labelTitulo;
    private JLabel labelEstado;
    private JProgressBar barraProgresso;
    private JTextArea areaLog;
    private PainelGrafico painelGrafico;

    private boolean darkMode;
    private Queue<Integer> historico = new LinkedList<>();

    // Thread que anima a barra (declarada para controlar / interromper)
    private Thread atualizacaoThread;

    public JanelaMonitorizacao(String titulo) {
        int hora = LocalTime.now().getHour();
        darkMode = (hora >= 18 || hora <= 6);

        setTitle("📡 Monitorização em Tempo Real - " + titulo);
        setSize(950, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        Color corTexto = darkMode ? new Color(230, 230, 250) : new Color(25, 25, 112);
        Color corFundo = darkMode ? new Color(20, 24, 38) : new Color(240, 245, 255);

        // Cabeçalho
        labelTitulo = new JLabel(titulo, SwingConstants.CENTER);
        labelTitulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 20));
        labelTitulo.setForeground(corTexto);
        add(labelTitulo, BorderLayout.NORTH);

        // Painel gráfico
        painelGrafico = new PainelGrafico(darkMode);
        add(painelGrafico, BorderLayout.CENTER);

        // Barra de progresso
        barraProgresso = new JProgressBar(0, 100);
        barraProgresso.setStringPainted(true);
        barraProgresso.setFont(new Font("Segoe UI Emoji", Font.BOLD, 13));
        barraProgresso.setForeground(darkMode ? new Color(139, 92, 246) : new Color(101, 44, 194));
        barraProgresso.setBackground(darkMode ? new Color(35, 40, 60) : Color.WHITE);
        barraProgresso.setPreferredSize(new Dimension(100, 25));
        add(barraProgresso, BorderLayout.SOUTH);

        // Painel lateral (log)
        JPanel painelLateral = new JPanel(new BorderLayout());
        painelLateral.setPreferredSize(new Dimension(250, 0));
        painelLateral.setBackground(darkMode ? new Color(25, 29, 42) : new Color(250, 250, 255));
        painelLateral.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(darkMode ? new Color(90, 90, 150) : new Color(200, 200, 255)),
            "📊 Log de Atualizações"
        ));

        areaLog = new JTextArea();
        areaLog.setEditable(false);
        areaLog.setFont(new Font("Consolas", Font.PLAIN, 12));
        areaLog.setForeground(darkMode ? new Color(200, 210, 255) : new Color(40, 40, 70));
        areaLog.setBackground(darkMode ? new Color(25, 29, 42) : Color.WHITE);
        JScrollPane scroll = new JScrollPane(areaLog);
        painelLateral.add(scroll, BorderLayout.CENTER);
        add(painelLateral, BorderLayout.EAST);

        // Estado textual (baixo do título)
        labelEstado = new JLabel("⏳ Aguardando início...", SwingConstants.CENTER);
        labelEstado.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        labelEstado.setForeground(corTexto);
        // já adicionámos o labelTitulo no NORTH; para evitar duplica-lo, não o adicionamos de novo

        getContentPane().setBackground(corFundo);
        setVisible(true);
    }

    // Atualização em tempo real — agora com protecções e limites
    public void atualizarProgresso(int percentagem, String texto) {
        // Limita percentagem entre 0 e 100
        int alvo = Math.max(0, Math.min(100, percentagem));
        final String textoFinal = texto == null ? "" : texto;
        labelEstado.setText(textoFinal);

        // Se já há uma animação a correr, interrompe-a antes de iniciar nova
        if (atualizacaoThread != null && atualizacaoThread.isAlive()) {
            atualizacaoThread.interrupt();
            try {
                // dá um pequeno tempo para a thread anterior terminar
                atualizacaoThread.join(30);
            } catch (InterruptedException ignored) {}
        }

        // Se o valor já é o mesmo, apenas atualiza rótulo e retorna
        int atual = barraProgresso.getValue();
        if (atual == alvo) {
            barraProgresso.setString(alvo + "%");
            painelGrafico.setProgresso(alvo);
            // atualiza histórico mesmo que seja igual (opcional)
            synchronized (historico) {
                historico.add(alvo);
                if (historico.size() > 30) historico.poll();
                painelGrafico.setHistorico(historico);
            }
            return;
        }

        // Nova thread para animar do valor atual até ao alvo
        atualizacaoThread = new Thread(() -> {
            int inicio = barraProgresso.getValue();
            int passo = (alvo > inicio) ? 1 : -1;
            int i = inicio;

            while (i != alvo && !Thread.currentThread().isInterrupted()) {
                final int valor = i;
                SwingUtilities.invokeLater(() -> {
                    barraProgresso.setValue(valor);
                    painelGrafico.setProgresso(valor);
                    barraProgresso.setString(valor + "%");
                });

                try {
                    Thread.sleep(15); // velocidade suave
                } catch (InterruptedException e) {
                    // Se interrompido, aplica o valor de destino direto e termina
                    SwingUtilities.invokeLater(() -> {
                        barraProgresso.setValue(alvo);
                        painelGrafico.setProgresso(alvo);
                        barraProgresso.setString(alvo + "%");
                    });
                    return;
                }

                i += passo;
            }

            // Garante que fica exatamente no valor alvo (pode não entrar no ciclo se já igual)
            SwingUtilities.invokeLater(() -> {
                barraProgresso.setValue(alvo);
                painelGrafico.setProgresso(alvo);
                barraProgresso.setString(alvo + "%");
            });

            // Atualiza o histórico de forma sincronizada
            synchronized (historico) {
                historico.add(alvo);
                if (historico.size() > 30) historico.poll();
                painelGrafico.setHistorico(historico);
            }
        });

        atualizacaoThread.setDaemon(true);
        atualizacaoThread.start();
    }

    public void adicionarLog(String mensagem) {
        areaLog.append("• " + mensagem + "\n");
        areaLog.setCaretPosition(areaLog.getDocument().getLength());
    }

    // Painel interno de gráficos (idêntico ao teu original)
    private static class PainelGrafico extends JPanel {
        private int progresso = 0;
        private Queue<Integer> historico = new LinkedList<>();
        private boolean darkMode;

        public PainelGrafico(boolean darkMode) {
            this.darkMode = darkMode;
        }

        public void setProgresso(int valor) {
            this.progresso = valor;
            repaint();
        }

        public void setHistorico(Queue<Integer> h) {
            this.historico = new LinkedList<>(h);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth();
            int h = getHeight();

            GradientPaint grad = darkMode
                ? new GradientPaint(0, 0, new Color(18, 18, 28), 0, h, new Color(25, 25, 40))
                : new GradientPaint(0, 0, new Color(245, 250, 255), 0, h, new Color(210, 220, 255));
            g2.setPaint(grad);
            g2.fillRect(0, 0, w, h);

            int raio = 110;
            int cx = w / 3;
            int cy = h / 2;
            int angulo = (int) (progresso * 3.6);

            Color corPrincipal = darkMode ? new Color(139, 92, 246) : new Color(101, 44, 194);
            Color corNeon = darkMode ? new Color(180, 160, 255) : new Color(120, 80, 255);

            g2.setColor(darkMode ? new Color(40, 40, 60) : new Color(230, 230, 240));
            g2.fillOval(cx - raio, cy - raio, 2 * raio, 2 * raio);

            g2.setPaint(new GradientPaint(cx - raio, cy, corNeon, cx + raio, cy, corPrincipal));
            g2.fillArc(cx - raio, cy - raio, 2 * raio, 2 * raio, 90, -angulo);

            g2.setColor(darkMode ? new Color(20, 20, 30) : Color.WHITE);
            g2.fillOval(cx - 70, cy - 70, 140, 140);

            g2.setColor(corPrincipal);
            g2.setFont(new Font("Segoe UI Emoji", Font.BOLD, 26));
            String txt = progresso + "%";
            int tw = g2.getFontMetrics().stringWidth(txt);
            g2.drawString(txt, cx - tw / 2, cy + 10);

            g2.setColor(new Color(255, 255, 255, 40));
            g2.fillOval(cx - 80, cy - 85, 160, 60);

            if (!historico.isEmpty()) {
                int xBase = w / 2 + 50;
                int yBase = h - 50;
                int largura = w / 2 - 80;

                g2.setColor(darkMode ? new Color(180, 180, 220) : new Color(60, 60, 90));
                g2.drawString("Histórico de Progresso", xBase, 30);

                int[] pontos = historico.stream().mapToInt(Integer::intValue).toArray();
                g2.setStroke(new BasicStroke(2));
                g2.setColor(corPrincipal);

                int n = pontos.length;
                for (int i = 1; i < n; i++) {
                    int x1 = xBase + (i - 1) * (largura / Math.max(1, n));
                    int y1 = yBase - (int) (pontos[i - 1] * 1.5);
                    int x2 = xBase + i * (largura / Math.max(1, n));
                    int y2 = yBase - (int) (pontos[i] * 1.5);
                    g2.drawLine(x1, y1, x2, y2);
                }

                g2.setColor(new Color(100, 100, 160, 100));
                g2.drawRect(xBase, yBase - 160, largura, 160);
            }
        }
    }
}
