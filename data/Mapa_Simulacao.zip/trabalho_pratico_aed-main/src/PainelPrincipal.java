//package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;

import algoritms.Dijkstra;
import models.Aresta;
import models.Grafo;
import models.No;
import util.ConversorTempo;
import util.GrafoLoader;

public class PainelPrincipal extends JFrame {
    private List<No> cidades = new ArrayList<>();
    private List<Aresta> conexoes = new ArrayList<>();
    private PainelGrafo painelGrafo;
    private JComboBox<String> comboOrigem, comboDestino;
    private JLabel labelDistancia;
    private JTextArea areaResultado;
    private JLabel labelStatus;
    private JLabel labelInfo;
    private JComboBox<String> comboOrigemBusca;
    
    // JTree para visualização hierárquica
    private JTree treeResultados;
    private DefaultMutableTreeNode rootNode;
    private DefaultTreeModel treeModel;
    
    // Log de transações para PDF
    private List<String> transactionLog = new ArrayList<>();
    // Guarda todo o texto do TextArea ao longo do tempo
    private List<String> textoAcumulado = new ArrayList<>();
    
    // Variáveis para animação
    private AnimadorGrafo animador;
    private PainelPrincipal frameParent;
    private JButton btnIniciarAnimacao;
    private JButton btnPararAnimacao;
    private JLabel labelProgresso;
    private List<Aresta> ultimoResultado = null;
    private AnimadorComboio animadorComboio;
    private JButton btnIniciarComboio;
    private JButton btnPausarComboio;
    private JButton btnPararComboio;
    private JLabel labelProgressoComboio;

    // Grafo
    Grafo g;
    Dijkstra dk;

    // Cores modernas
    private static final Color COR_PRIMARIA = new Color(101, 44, 194);
    private static final Color COR_SECUNDARIA = new Color(139, 92, 246);
    private static final Color COR_SUCESSO = new Color(52, 19, 110);
    private static final Color COR_PERIGO = new Color(93, 34, 197);
    private static final Color COR_TEXTO_ESCURO = new Color(17, 24, 39);
    private static final Color COR_TEXTO_MEDIO = new Color(75, 85, 99);
    private static final Color COR_FUNDO = new Color(249, 250, 251);
    private static final Color COR_CARD = Color.WHITE;
    private static final Color COR_BORDA = new Color(229, 231, 235);

    public PainelPrincipal() {
        super("Sistema de Logística Militar - Ucrânia");
        
        inicializarDados();
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1600, 900);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(0, 0));
        getContentPane().setBackground(COR_FUNDO);
        
        criarInterface();
        
        setVisible(true);
    }
    
    private void inicializarDados() {
        g = GrafoLoader.carregarMapaUcrania();
        dk = new Dijkstra();
        
        HashMap<String, No> nosMap = g.getNos();
        cidades = new ArrayList<>(nosMap.values());
        
        HashMap<String, ArrayList<Aresta>> listasAdj = g.getListasAdj();
        
        for (String nomeOrigem : listasAdj.keySet()) {
            ArrayList<Aresta> arestasOrigem = listasAdj.get(nomeOrigem);
            for (Aresta aresta : arestasOrigem) {
                conexoes.add(aresta);
            }
        }
        
        logTransaction("Sistema inicializado", "Carregadas " + cidades.size() + " cidades e " + (conexoes.size()/2) + " conexões");
    }
    
    private No getCidadePorNome(String nome) {
        return cidades.stream().filter(c -> c.getNome().equals(nome)).findFirst().orElse(null);
    }
    
    private void acumularTextoArea() {
        if (areaResultado != null) {
            String textoAtual = areaResultado.getText().trim();
            if (!textoAtual.isEmpty()) {
                // Evita duplicados consecutivos
                if (textoAcumulado.isEmpty() || !textoAcumulado.get(textoAcumulado.size() - 1).equals(textoAtual)) {
                    textoAcumulado.add(textoAtual);
                }
            }
        }
    }


    private void conectar(String nomeOrigem, String nomeDestino, int distancia) {
        No origem = getCidadePorNome(nomeOrigem);
        No destino = getCidadePorNome(nomeDestino);
        if (origem != null && destino != null) {
            conexoes.add(new Aresta(origem, destino, distancia));
            conexoes.add(new Aresta(destino, origem, distancia));
        }
    }
    
    private void criarInterface() {
        JPanel painelTopo = criarPainelTopo();
        add(painelTopo, BorderLayout.NORTH);
        
        // Painel central com split
        JSplitPane splitPrincipal = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPrincipal.setResizeWeight(0.6);
        splitPrincipal.setBorder(null);
        
        // Lado esquerdo - Grafo
        JPanel painelCentral = new JPanel(new BorderLayout());
        painelCentral.setBackground(COR_FUNDO);
        painelCentral.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        painelGrafo = new PainelGrafo(cidades, conexoes);
        painelGrafo.setFrameParent(this);
        painelGrafo.setAtualizarComboboxCallback(() -> atualizarComboboxes());
        painelGrafo.setBorder(new CompoundBorder(
            new LineBorder(COR_BORDA, 1, true),
            new EmptyBorder(10, 10, 10, 10)
        ));
        painelGrafo.setBackground(Color.WHITE);
        painelCentral.add(painelGrafo, BorderLayout.CENTER);
        
        splitPrincipal.setLeftComponent(painelCentral);
        
        // Lado direito - Controles
        JPanel painelControlos = criarPainelControlos();
        splitPrincipal.setRightComponent(painelControlos);
        
        add(splitPrincipal, BorderLayout.CENTER);
        
        JPanel painelRodape = criarPainelRodape();
        add(painelRodape, BorderLayout.SOUTH);
        
        animador = new AnimadorGrafo(painelGrafo, btnIniciarAnimacao, btnPararAnimacao, labelProgresso);
        // animadorComboio será criado no criarSecaoComboio() quando os botões forem criados
    }
    
    private JPanel criarPainelTopo() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(COR_PRIMARIA);
        painel.setBorder(new EmptyBorder(25, 35, 25, 35));
        
        JPanel painelEsquerda = new JPanel(new GridLayout(2, 1, 0, 8));
        painelEsquerda.setOpaque(false);
        
        JLabel titulo = new JLabel("🎯 Sistema de Logística Militar");
        titulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 32));
        titulo.setForeground(Color.WHITE);
        
        JLabel subtitulo = new JLabel("Otimização inteligente de rotas estratégicas na Ucrânia");
        subtitulo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 15));
        subtitulo.setForeground(new Color(224, 231, 255));
        
        painelEsquerda.add(titulo);
        painelEsquerda.add(subtitulo);
        
        JPanel painelDireita = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        painelDireita.setOpaque(false);
        
        labelInfo = new JLabel();
        actualizarContadores();
        labelInfo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 14));
        labelInfo.setForeground(Color.WHITE);
        labelInfo.setBorder(new CompoundBorder(
            new LineBorder(new Color(255, 255, 255, 50), 1, true),
            new EmptyBorder(10, 20, 10, 20)
        ));
        
        painelDireita.add(labelInfo);
        
        painel.add(painelEsquerda, BorderLayout.WEST);
        painel.add(painelDireita, BorderLayout.EAST);
        
        return painel;
    }

    private void actualizarContadores() {
        if (labelInfo != null) {
            labelInfo.setText(String.format("🏙 %d Cidades  •  🔗 %d Conexões", 
                cidades.size(), conexoes.size() / 2));
        }
    }
    
    private JPanel criarPainelControlos() {
        JPanel painelConteudo = new JPanel(new BorderLayout());
        painelConteudo.setBackground(COR_CARD);
        
        // Split vertical - Controles em cima, resultados embaixo
        JSplitPane splitVertical = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitVertical.setResizeWeight(0.45);
        splitVertical.setDividerLocation(400); // Garante espaço para "Resultados da Análise"
        splitVertical.setBorder(null);
        
        // Painel superior - Controles
        JPanel painelControles = new JPanel();
        painelControles.setLayout(new BoxLayout(painelControles, BoxLayout.Y_AXIS));
        painelControles.setBackground(COR_CARD);
        painelControles.setBorder(new EmptyBorder(20, 20, 10, 20));
        
        JLabel labelTitulo = new JLabel("⚙️ Algoritmos de Roteamento");
        labelTitulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 18));
        labelTitulo.setForeground(COR_TEXTO_ESCURO);
        labelTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelControles.add(labelTitulo);
        painelControles.add(Box.createRigidArea(new Dimension(0, 20)));
        
        painelControles.add(criarControlesAnimacao());
        painelControles.add(Box.createRigidArea(new Dimension(0, 15)));
        
        painelControles.add(criarSecao("📊 Representação do Grafo", new String[] {
            "Matriz de Adjacência",
            "Lista de Adjacências"
        }, new ActionListener[] {
            e -> exibirMatrizAdjacencia(),
            e -> exibirListaAdjacencia()
        }));
        painelControles.add(Box.createRigidArea(new Dimension(0, 15)));

        painelControles.add(criarSecaoBuscas());
        painelControles.add(Box.createRigidArea(new Dimension(0, 15)));
        
        painelControles.add(criarSecao("🌳 Árvore Geradora Mínima", new String[] {
            "Algoritmo de Kruskal",
            "Algoritmo de Prim"
        }, new ActionListener[] {
            e -> executarKruskal(),
            e -> executarPrim()
        }));
        
        painelControles.add(Box.createRigidArea(new Dimension(0, 15)));
        
        JPanel secaoCaminho = criarSecaoCaminhoMinimo();
        painelControles.add(secaoCaminho);
        
        JScrollPane scrollControles = new JScrollPane(painelControles);
        scrollControles.setBorder(null);
        scrollControles.getVerticalScrollBar().setUnitIncrement(16);
        
        splitVertical.setTopComponent(scrollControles);
        
        // Painel inferior - Resultados com JTree e TextArea
        JPanel painelResultados = criarPainelResultadosExtendido();
        splitVertical.setBottomComponent(painelResultados);
        
        painelConteudo.add(splitVertical, BorderLayout.CENTER);
        
        return painelConteudo;
    }

    private JPanel criarPainelResultadosExtendido() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(COR_CARD);
        painel.setBorder(new EmptyBorder(10, 20, 20, 20));
        
        // Cabeçalho com botão de exportação
        JPanel painelHeader = new JPanel(new BorderLayout());
        painelHeader.setOpaque(false);
        
        JLabel labelTitulo = new JLabel("📋 Resultados da Análise");
        labelTitulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 15));
        labelTitulo.setForeground(COR_TEXTO_ESCURO);
        
        JButton btnExportPDF = criarBotaoSecundario("📄 Exportar PDF");
        btnExportPDF.setMaximumSize(new Dimension(150, 35));
        btnExportPDF.addActionListener(e -> exportarParaPDF());
        
        painelHeader.add(labelTitulo, BorderLayout.WEST);
        painelHeader.add(btnExportPDF, BorderLayout.EAST);
        
        painel.add(painelHeader, BorderLayout.NORTH);
        
        // Abas para JTree e TextArea
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        tabbedPane.setUI(new ModernTabbedPaneUI());
        tabbedPane.setOpaque(false);
        tabbedPane.setBackground(Color.WHITE);
        tabbedPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        
        // Aba 1 - JTree
        rootNode = new DefaultMutableTreeNode("Histórico de Operações");
        treeModel = new DefaultTreeModel(rootNode);
        treeResultados = new JTree(treeModel);
        treeResultados.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
        treeResultados.setRowHeight(25);
        
        // Menu contexto para JTree
        JPopupMenu popupTree = new JPopupMenu();
        JMenuItem itemExportar = new JMenuItem("📄 Exportar para PDF");
        itemExportar.addActionListener(e -> exportarParaPDF());
        JMenuItem itemLimpar = new JMenuItem("🗑️ Limpar Histórico");
        itemLimpar.addActionListener(e -> limparHistorico());
        popupTree.add(itemExportar);
        popupTree.add(itemLimpar);

        JMenuItem itemProgramadores = new JMenuItem("👨‍💻 Abrir Janela dos Programadores");
        itemProgramadores.addActionListener(e -> {
            // abre a janela animada dos programadores
            SwingUtilities.invokeLater(() -> {
                JFrame frame = new JFrame("Nó dos Programadores");
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setContentPane(new GraphPanel()); // classe do GraficoAnimadoProgramadores
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            });
        });
        popupTree.add(itemProgramadores);

        
        treeResultados.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popupTree.show(e.getComponent(), e.getX(), e.getY());
                }
            }
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popupTree.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        });
        
        JScrollPane scrollTree = new JScrollPane(treeResultados);
        scrollTree.setBorder(new LineBorder(COR_BORDA, 1));

        treeResultados.setCellRenderer(new ModernTreeCellRenderer());
        treeResultados.setOpaque(false);

        
        // Aba 2 - TextArea detalhado
        areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        areaResultado.setFont(new Font("Consolas Emoji", Font.PLAIN, 12));
        areaResultado.setBackground(Color.WHITE);
        areaResultado.setBorder(new EmptyBorder(10, 10, 10, 10));
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        areaResultado.setForeground(COR_TEXTO_ESCURO);

                // Aba 2 - TextArea detalhado
        areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        areaResultado.setFont(new Font("Consolas Emoji", Font.PLAIN, 12));
        areaResultado.setBackground(Color.WHITE);
        areaResultado.setBorder(new EmptyBorder(10, 10, 10, 10));
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        areaResultado.setForeground(COR_TEXTO_ESCURO);

        // ✅ Escuta alterações no JTextArea e acumula o texto automaticamente
        areaResultado.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                acumularTextoArea();
            }
            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                // opcional: poderias limpar ou ignorar
            }
            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                // não usado em JTextArea
            }
        });

        
        JScrollPane scrollText = new JScrollPane(areaResultado);
        scrollText.setBorder(new LineBorder(COR_BORDA, 1));
        
        tabbedPane.addTab("🌳 Árvore de Operações", scrollTree);
        tabbedPane.addTab("📝 Detalhes", scrollText);
        
        painel.add(tabbedPane, BorderLayout.CENTER);
        
        // Label de distância na parte inferior
        labelDistancia = new JLabel("⏳ Aguardando cálculo...");
        labelDistancia.setFont(new Font("Segoe UI Emoji", Font.BOLD, 13));
        labelDistancia.setForeground(COR_PRIMARIA);
        labelDistancia.setBorder(new EmptyBorder(10, 0, 0, 0));
        painel.add(labelDistancia, BorderLayout.SOUTH);
        
        return painel;
    }

    /**
     * Renderer personalizado para o JTree com estilo moderno e g2d.
     */
    class ModernTreeCellRenderer extends DefaultTreeCellRenderer {
        private static final Color BACKGROUND_SELECTION = new Color(99, 102, 241, 40);
        private static final Color BORDER_SELECTION = new Color(99, 102, 241);
        private static final Color TEXT_NORMAL = new Color(17, 24, 39);

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded,
                                                    boolean leaf, int row, boolean hasFocus) {
            JLabel label = (JLabel) super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
            label.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
            label.setForeground(TEXT_NORMAL);
            label.setOpaque(false);
            return label;
        }

        @Override
        public void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (getBackgroundSelectionColor() != null && getParent() != null) {
                if (getParent() instanceof JTree && ((JTree) getParent()).getSelectionPath() != null) {
                    g2d.setColor(BACKGROUND_SELECTION);
                    g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                    g2d.setColor(BORDER_SELECTION);
                    g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                }
            }

            super.paintComponent(g);
            g2d.dispose();
        }
    }

    /**
     * UI personalizada para o JTabbedPane com efeito gradiente.
     */
    class ModernTabbedPaneUI extends javax.swing.plaf.basic.BasicTabbedPaneUI {
        private final Color corAtiva = new Color(99, 102, 241);
        private final Color corInativa = new Color(229, 231, 235);

        @Override
        protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex,
                                        int x, int y, int w, int h, boolean isSelected) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            GradientPaint grad;
            if (isSelected) {
                grad = new GradientPaint(x, y, corAtiva.brighter(), x, y + h, corAtiva.darker());
            } else {
                grad = new GradientPaint(x, y, corInativa, x, y + h, Color.WHITE);
            }
            g2d.setPaint(grad);
            g2d.fillRoundRect(x + 4, y + 4, w - 8, h, 15, 15);
            g2d.dispose();
        }

        @Override
        protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex,
                                    int x, int y, int w, int h, boolean isSelected) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(isSelected ? corAtiva.darker() : new Color(200, 200, 200));
            g2.drawRoundRect(x + 4, y + 4, w - 8, h, 15, 15);
            g2.dispose();
        }

        @Override
        protected void paintFocusIndicator(Graphics g, int tabPlacement,
                                        Rectangle[] rects, int tabIndex,
                                        Rectangle iconRect, Rectangle textRect, boolean isSelected) {
            // Remove indicador de foco padrão
        }
    }


    private void atualizarTreeResultados(String operacao, String detalhes) {
            SwingUtilities.invokeLater(() -> {
                String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
                DefaultMutableTreeNode operacaoNode = new DefaultMutableTreeNode(timestamp + " - " + operacao);
                
                if (detalhes != null && !detalhes.isEmpty()) {
                    String[] linhas = detalhes.split("\n");
                    for (String linha : linhas) {
                        if (!linha.trim().isEmpty()) {
                            operacaoNode.add(new DefaultMutableTreeNode(linha.trim()));
                        }
                    }
                }
                
                rootNode.add(operacaoNode);
                treeModel.reload();
                
                // Expandir último nó adicionado
                int rowCount = treeResultados.getRowCount();
                treeResultados.expandRow(rowCount - 1);
                treeResultados.scrollRowToVisible(rowCount - 1);
            });
        }

        private void logTransaction(String operacao, String detalhes) {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
            String log = String.format("[%s] %s: %s", timestamp, operacao, detalhes);
            transactionLog.add(log);
        }

       private void exportarParaPDF() {
        // Garante que o conteúdo mais recente está guardado
        acumularTextoArea();

        // Junta todo o texto acumulado do textarea
        StringBuilder conteudoCompleto = new StringBuilder();
        for (String texto : textoAcumulado) {
            conteudoCompleto.append(texto).append("\n\n");
        }

        // Cria objeto com dados para PDF
        RelatorioPDF relatorio = new RelatorioPDF(
                "RELATÓRIO DO SISTEMA DE LOGÍSTICA MILITAR - UCRÂNIA",
                transactionLog,
                conteudoCompleto.toString()
        );

        // Gera o PDF
        relatorio.gerarPDF(this);

        // Regista no log
        logTransaction("Exportação PDF", "Relatório gerado com sucesso com " + textoAcumulado.size() + " secções");
    }

    

    private void exportarParaPDF1() {
        try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd_MM_yyyy_HH:mm:ss"));
            String filename = "relatorio_logistica_" + timestamp + ".txt";
            
            
            FileWriter writer = new FileWriter(filename);
            writer.write("=".repeat(80) + "\n");
            writer.write("       RELATÓRIO DO SISTEMA DE LOGÍSTICA MILITAR - UCRÂNIA\n");
            writer.write("=".repeat(100) + "\n\n");
            writer.write("Data de Geração: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")) + "\n\n");
            writer.write("-".repeat(100) + "\n");
            writer.write("HISTÓRICO DE TRANSAÇÕES\n");
            writer.write("-".repeat(80) + "\n\n");
            
            for (String log : transactionLog) {
                writer.write(log + "\n");
            }
            
            writer.write("\n" + "-".repeat(80) + "\n");
            writer.write("ÚLTIMO RESULTADO DETALHADO\n");
            writer.write("-".repeat(80) + "\n\n");
            writer.write(areaResultado.getText());
            
            writer.write("\n\n" + "=".repeat(80) + "\n");
            writer.write("Fim do Relatório\n");
            writer.write("=".repeat(80) + "\n");
            
            writer.close();
            
            JOptionPane.showMessageDialog(this,
                "✅ Relatório exportado com sucesso!\n\nFicheiro: " + filename,
                "Exportação Concluída",
                JOptionPane.INFORMATION_MESSAGE);
            
            logTransaction("Exportação PDF", "Ficheiro gerado: " + filename);
            
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                "❌ Erro ao exportar relatório:\n" + ex.getMessage(),
                "Erro",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limparHistorico() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Tem certeza que deseja limpar todo o histórico?",
            "Confirmação",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            rootNode.removeAllChildren();
            treeModel.reload();
            transactionLog.clear();
            textoAcumulado.clear(); // ✅ limpa também o texto acumulado
            areaResultado.setText("");
            logTransaction("Sistema", "Histórico limpo");
            JOptionPane.showMessageDialog(this, "✅ Histórico limpo com sucesso!");
        }
    }
    
    private JPanel criarSecaoBuscas() {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setOpaque(false);
        painel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JLabel label = new JLabel("🔍 Algoritmos de Busca");
        label.setFont(new Font("Segoe UI Emoji", Font.BOLD, 15));
        label.setForeground(COR_TEXTO_ESCURO);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.add(label);
        painel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        painel.add(criarCampo("Cidade de Origem", comboOrigemBusca = criarCombo()));
        painel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        JButton btnDFS = criarBotaoSecundario("🌲 Busca em Profundidade (DFS)");
        btnDFS.addActionListener(e -> executarDFS());
        painel.add(btnDFS);
        painel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        JButton btnBFS = criarBotaoSecundario("🌊 Busca em Largura (BFS)");
        btnBFS.addActionListener(e -> executarBFS());
        painel.add(btnBFS);
        
        return painel;
    }
    
    private JPanel criarControlesAnimacao() {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setOpaque(false);
        painel.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.setBorder(new CompoundBorder(
            new LineBorder(COR_PRIMARIA, 2, true),
            new EmptyBorder(18, 18, 18, 18)
        ));
        painel.setBackground(new Color(248, 250, 252));
        
        JLabel label = new JLabel("🎬 Controlo de Animação");
        label.setFont(new Font("Segoe UI Emoji", Font.BOLD, 15));
        label.setForeground(COR_TEXTO_ESCURO);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.add(label);
        painel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        labelProgresso = new JLabel("⏳ Aguardando execução...");
        labelProgresso.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
        labelProgresso.setForeground(COR_TEXTO_MEDIO);
        labelProgresso.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.add(labelProgresso);
        painel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        JPanel painelBotoes = new JPanel(new GridLayout(1, 2, 10, 0));
        painelBotoes.setOpaque(false);
        painelBotoes.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelBotoes.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        
        btnIniciarAnimacao = criarBotaoAnimacao("▶️ Iniciar", COR_SUCESSO);
        btnIniciarAnimacao.addActionListener(e -> iniciarAnimacao());
        
        btnPararAnimacao = criarBotaoAnimacao("⏸️ Parar", COR_PERIGO);
        btnPararAnimacao.setEnabled(false);
        btnPararAnimacao.addActionListener(e -> animador.pararAnimacao());
        
        painelBotoes.add(btnIniciarAnimacao);
        painelBotoes.add(btnPararAnimacao);
        
        painel.add(painelBotoes);
        
        return painel;
    }
    
    private JButton criarBotaoAnimacao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI Emoji", Font.BOLD, 13));
        botao.setForeground(Color.WHITE);
        botao.setBackground(cor);
        botao.setBorderPainted(false);
        botao.setFocusPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        botao.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (botao.isEnabled()) {
                    botao.setBackground(cor.darker());
                }
            }
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    public void setFrameParent(PainelPrincipal frame) {
        this.frameParent = frame;
    }
    
    private void iniciarAnimacao() {
        if (ultimoResultado == null || ultimoResultado.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Execute primeiro um algoritmo (Dijkstra, Kruskal ou Prim) para animar!",
                "Aviso",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        animador.resetar();
        animador.iniciarAnimacao(ultimoResultado, () -> {
            labelProgresso.setText("✅ Concluído com sucesso!");
            labelStatus.setText("✅ Animação finalizada");
        });
    }

    private JPanel criarSecao(String titulo, String[] botoes, ActionListener[] acoes) {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setOpaque(false);
        painel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JLabel label = new JLabel(titulo);
        label.setFont(new Font("Segoe UI Emoji", Font.BOLD, 15));
        label.setForeground(COR_TEXTO_ESCURO);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.add(label);
        painel.add(Box.createRigidArea(new Dimension(0, 12)));
        
        for (int i = 0; i < botoes.length; i++) {
            JButton btn = criarBotaoSecundario(botoes[i]);
            btn.addActionListener(acoes[i]);
            painel.add(btn);
            if (i < botoes.length - 1) {
                painel.add(Box.createRigidArea(new Dimension(0, 10)));
            }
        }
        
        return painel;
    }
    
    private JPanel criarSecaoCaminhoMinimo() {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setOpaque(false);
        painel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JLabel label = new JLabel("🚀 Caminho Mínimo (Dijkstra)");
        label.setFont(new Font("Segoe UI Emoji", Font.BOLD, 15));
        label.setForeground(COR_TEXTO_ESCURO);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.add(label);
        painel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        painel.add(criarCampo("Cidade de Origem", comboOrigem = criarCombo()));
        painel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        painel.add(criarCampo("Cidade de Destino", comboDestino = criarCombo()));
        painel.add(Box.createRigidArea(new Dimension(0, 18)));
        
        JButton btnDijkstra = criarBotaoPrimario("Calcular Rota Ótima", "🎯");
        btnDijkstra.addActionListener(e -> executarDijkstra());
        painel.add(btnDijkstra);
        painel.add(Box.createRigidArea(new Dimension(0, 18)));
        
        painel.add(criarSecaoComboio());
        painel.add(Box.createRigidArea(new Dimension(0, 18)));
        
        JButton btnLimpar = criarBotaoSecundario("🔄 Limpar Visualização");
        btnLimpar.addActionListener(e -> limparResultados());
        painel.add(btnLimpar);
        
        return painel;
    }

    private JPanel criarSecaoComboio() {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setOpaque(false);
        painel.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.setBorder(new CompoundBorder(
            new LineBorder(new Color(34, 197, 94), 2, true),
            new EmptyBorder(15, 15, 15, 15)
        ));
        painel.setBackground(new Color(240, 253, 244));

        JLabel labelTitulo = new JLabel("🚂 TSP - Percurso Completo");
        labelTitulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 14));
        labelTitulo.setForeground(COR_TEXTO_ESCURO);
        labelTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.add(labelTitulo);
        painel.add(Box.createRigidArea(new Dimension(0, 8)));

        JLabel labelDesc = new JLabel("<html><b>Heurística do Vizinho Mais Próximo</b><br>Visita todos os nós usando arestas existentes<br>com backtracking quando necessário</html>");
        labelDesc.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 11));
        labelDesc.setForeground(COR_TEXTO_MEDIO);
        labelDesc.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.add(labelDesc);
        painel.add(Box.createRigidArea(new Dimension(0, 12)));

        labelProgressoComboio = new JLabel("⏳ Aguardando início...");
        labelProgressoComboio.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 12));
        labelProgressoComboio.setForeground(COR_TEXTO_MEDIO);
        labelProgressoComboio.setAlignmentX(Component.LEFT_ALIGNMENT);
        painel.add(labelProgressoComboio);
        painel.add(Box.createRigidArea(new Dimension(0, 12)));

        // Grid com 3 botões: Iniciar, Pausar, Parar
        JPanel painelBotoes = new JPanel(new GridLayout(1, 3, 8, 0));
        painelBotoes.setOpaque(false);
        painelBotoes.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelBotoes.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        btnIniciarComboio = criarBotaoAnimacao("▶️ Iniciar", COR_SUCESSO);

        btnPausarComboio = criarBotaoAnimacao("⏸️ Pausar", new Color(251, 146, 60));
        btnPausarComboio.setEnabled(false);

        btnPararComboio = criarBotaoAnimacao("⏹️ Parar", COR_PERIGO);
        btnPararComboio.setEnabled(false);

        painelBotoes.add(btnIniciarComboio);
        painelBotoes.add(btnPausarComboio);
        painelBotoes.add(btnPararComboio);

        painel.add(painelBotoes);

        // Criar animadorComboio agora que todos os botões foram criados
        animadorComboio = new AnimadorComboio(painelGrafo, btnIniciarComboio, btnPararComboio, btnPausarComboio, labelProgressoComboio);

        // Adicionar ActionListeners agora que animadorComboio existe
        btnIniciarComboio.addActionListener(e -> iniciarComboio());

        btnPausarComboio.addActionListener(e -> {
            if (animadorComboio != null) {
                animadorComboio.pausarAnimacao();
                btnPausarComboio.setEnabled(false);
            }
        });

        btnPararComboio.addActionListener(e -> {
            if (animadorComboio != null) {
                animadorComboio.pararAnimacao();
                btnPausarComboio.setEnabled(false);
            }
        });

        return painel;
    }

    private void iniciarComboio() {
        String origem = (String) comboOrigem.getSelectedItem();

        if (origem == null || origem.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "⚠️ Selecione uma cidade de origem!",
                "Aviso",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        No cidadeOrigem = getCidadePorNome(origem);

        if (cidadeOrigem == null) {
            JOptionPane.showMessageDialog(this,
                "❌ Cidade de origem não encontrada!",
                "Erro",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (animador != null) {
            animador.pararAnimacao();
        }

        // Usar novo método que aceita Grafo diretamente
        animadorComboio.iniciarPercursoCompleto(cidadeOrigem, g);

        labelStatus.setText("🚂 TSP iniciado a partir de " + origem);
        logTransaction("TSP (Comboio)", "Percurso completo iniciado de " + origem);
    }
    
    private JPanel criarCampo(String label, JComponent componente) {
        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));
        painel.setOpaque(false);
        painel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JLabel jLabel = new JLabel(label);
        jLabel.setFont(new Font("Segoe UI Emoji", Font.BOLD, 13));
        jLabel.setForeground(COR_TEXTO_MEDIO);
        jLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        componente.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        painel.add(jLabel);
        painel.add(Box.createRigidArea(new Dimension(0, 8)));
        painel.add(componente);
        
        return painel;
    }
    
    private void atualizarComboboxes() {
        String origemSelecionada = (String) comboOrigem.getSelectedItem();
        String destinoSelecionado = (String) comboDestino.getSelectedItem();
        String origemBuscaSelecionada = comboOrigemBusca != null ? (String) comboOrigemBusca.getSelectedItem() : null;
        
        comboOrigem.removeAllItems();
        comboDestino.removeAllItems();
        if (comboOrigemBusca != null) {
            comboOrigemBusca.removeAllItems();
        }
        
        for (No cidade : cidades) {
            comboOrigem.addItem(cidade.getNome());
            comboDestino.addItem(cidade.getNome());
            if (comboOrigemBusca != null) {
                comboOrigemBusca.addItem(cidade.getNome());
            }
        }
        
        if (origemSelecionada != null) {
            comboOrigem.setSelectedItem(origemSelecionada);
        }
        if (destinoSelecionado != null) {
            comboDestino.setSelectedItem(destinoSelecionado);
        }
        if (origemBuscaSelecionada != null && comboOrigemBusca != null) {
            comboOrigemBusca.setSelectedItem(origemBuscaSelecionada);
        }
        
        actualizarContadores();
    }

    /*private JComboBox<String> criarCombo() {
        JComboBox<String> combo = new JComboBox<>();
        for (No cidade : cidades) {
            combo.addItem(cidade.getNome());
        }
        combo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        combo.setBackground(Color.WHITE);
        combo.setBorder(new CompoundBorder(
            new LineBorder(COR_BORDA, 2, true),
            new EmptyBorder(8, 12, 8, 12)
        ));
        combo.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return combo;
    }*/

    private JComboBox<String> criarCombo() {
        ComboBoxModerno<String> combo = new ComboBoxModerno<>();
        for (No cidade : cidades) {
            combo.addItem(cidade.getNome());
        }
        combo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        return combo;
    }

    private JButton criarBotaoPrimario(String texto, String emoji) {
        BotaoModerno botao = new BotaoModerno(emoji + " " + texto, COR_PRIMARIA);
        botao.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        botao.setAlignmentX(Component.LEFT_ALIGNMENT);
        return botao;
    }

    private JButton criarBotaoSecundario(String texto) {
        BotaoSecundario botao = new BotaoSecundario(texto, COR_PRIMARIA);
        botao.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        botao.setAlignmentX(Component.LEFT_ALIGNMENT);
        return botao;
    }

    
    private JPanel criarPainelRodape() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(new Color(31, 41, 55));
        painel.setBorder(new EmptyBorder(12, 35, 12, 35));
        
        labelStatus = new JLabel("✅ Sistema pronto para uso");
        labelStatus.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
        labelStatus.setForeground(new Color(156, 163, 175));
        
        JLabel labelDireita = new JLabel("Desenvolvido com Java Swing • 2024");
        labelDireita.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
        labelDireita.setForeground(new Color(156, 163, 175));
        
        painel.add(labelStatus, BorderLayout.WEST);
        painel.add(labelDireita, BorderLayout.EAST);
        
        return painel;
    }
    
    private void exibirMatrizAdjacencia() {
        animador.resetar();
        ultimoResultado = null;
        
        areaResultado.setText("╔══ MATRIZ DE ADJACÊNCIA ══╗\n\n");
        int n = cidades.size();
        int[][] matriz = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                No c1 = cidades.get(i);
                No c2 = cidades.get(j);
                matriz[i][j] = conexoes.stream()
                    .filter(c -> (c.getOrigem() == c1 && c.getDestino() == c2))
                    .mapToInt(c -> c.getPeso())
                    .findFirst()
                    .orElse(0);
            }
        }
        
        StringBuilder sb = new StringBuilder("        ");
        for (No c : cidades) {
            String nome = c.getNome().substring(0, Math.min(c.getNome().length(), 6));
            sb.append(String.format("%-8s", nome));
        }
        sb.append("\n");

        for (int i = 0; i < n; i++) {
            String nome = cidades.get(i).getNome().substring(0, Math.min(cidades.get(i).getNome().length(), 6));
            sb.append(String.format("%-8s", nome));
            for (int j = 0; j < n; j++) {
                sb.append(String.format("%-8d", matriz[i][j]));
            }
            sb.append("\n");
        }

         hide();
        Tabela_Matriz_Adjacencia tm=new Tabela_Matriz_Adjacencia(matriz, cidades.stream().map(No::getNome).toArray(String[]::new));
        tm.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {                
                show();
            }
        });
    
        areaResultado.append(sb.toString());
        labelDistancia.setText("✅ Matriz gerada com sucesso!");
        labelStatus.setText("📊 Matriz de adjacência exibida");

        painelGrafo.pararAnimacao();

        painelGrafo.setCaminhoDestacado(null);
        
        logTransaction("Matriz de Adjacência", "Gerada para " + n + " cidades");
        atualizarTreeResultados("Matriz de Adjacência", "Dimensão: " + n + "x" + n);
    }

    private void exibirListaAdjacencia() {
        animador.resetar();
        ultimoResultado = null;
        
        areaResultado.setText("╔══ LISTA DE ADJACÊNCIAS ══╗\n\n");
        Map<No, List<String>> adj = new LinkedHashMap<>();
        cidades.forEach(c -> adj.put(c, new ArrayList<>()));

        for(Aresta con : conexoes) {
            adj.get(con.getOrigem()).add(con.getDestino().getNome() + " (" + con.getPeso() + "km)");
        }
        
        StringBuilder detalhes = new StringBuilder();
        adj.forEach((cidade, vizinhos) -> {
            String linha = "📍 " + cidade.getNome() + " → " + vizinhos;
            areaResultado.append(linha + "\n");
            detalhes.append(cidade.getNome()).append(": ").append(vizinhos.size()).append(" conexões\n");
        });

        hide();
        Lista_Adjacencia_Janela la=new Lista_Adjacencia_Janela(cidades, conexoes);
        la.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                show();
            }
        });
        
        labelDistancia.setText("✅ Lista gerada com sucesso!");
        labelStatus.setText("📋 Lista de adjacências exibida");
        painelGrafo.setCaminhoDestacado(null);
        
        logTransaction("Lista de Adjacências", "Total de " + cidades.size() + " cidades");
        atualizarTreeResultados("Lista de Adjacências", detalhes.toString());
    }
    
    private void executarKruskal() {
        animador.resetar();

        // Usar classe Kruskal dedicada
        algoritms.Kruskal kruskal = new algoritms.Kruskal();
        List<Aresta> agm = kruskal.executar(g);

        if (agm == null || agm.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "❌ Erro ao executar Kruskal!",
                "Erro",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Calcular custo total
        int custoTotal = agm.stream().mapToInt(Aresta::getPeso).sum();

        ultimoResultado = new ArrayList<>(agm);
        painelGrafo.setCaminhoDestacado(agm);
        painelGrafo.iniciarAnimacao();

        ConversorTempo cc = new ConversorTempo();
        String tempo = cc.pesoParaTempo(custoTotal);

        areaResultado.setText("╔══ ALGORITMO DE KRUSKAL ══╗\n");
        areaResultado.append("Árvore Geradora Mínima (AGM)\n\n");

        StringBuilder detalhes = new StringBuilder();
        agm.forEach(c -> {
            String linha = "🔗 " + c.getOrigem().getNome() + " ↔ " + c.getDestino().getNome() + " (" + c.getPeso() + "km)";
            areaResultado.append(linha + "\n");
            detalhes.append(linha).append("\n");
        });

        labelDistancia.setText("💰 Custo total da AGM: " + custoTotal + " km" + tempo);
        labelStatus.setText("🌳 Kruskal executado - " + agm.size() + " arestas selecionadas");

        logTransaction("Kruskal", "AGM com " + agm.size() + " arestas, custo: " + custoTotal + "km");
        atualizarTreeResultados("Algoritmo de Kruskal", detalhes.toString());

        // Mostrar diálogo personalizado com resultados
        mostrarResumoKruskal(agm.size(), custoTotal, tempo, cidades.size());
    }

    private void executarPrim() {
        animador.resetar();

        if (cidades.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "⚠️ Nenhuma cidade cadastrada!",
                "Aviso",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Usar classe Prim dedicada
        algoritms.Prim prim = new algoritms.Prim();
        List<Aresta> agm = prim.executar(g);

        if (agm == null || agm.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "❌ Erro ao executar Prim!",
                "Erro",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Calcular custo total
        int custoTotal = agm.stream().mapToInt(Aresta::getPeso).sum();

        ultimoResultado = new ArrayList<>(agm);
        painelGrafo.setCaminhoDestacado(agm);
        painelGrafo.iniciarAnimacao();

        ConversorTempo cc = new ConversorTempo();
        String tempo = cc.pesoParaTempo(custoTotal);

        areaResultado.setText("╔══ ALGORITMO DE PRIM ══╗\n");
        areaResultado.append("Árvore Geradora Mínima (AGM)\n\n");

        StringBuilder detalhes = new StringBuilder();
        agm.forEach(c -> {
            String linha = "🔗 " + c.getOrigem().getNome() + " ↔ " + c.getDestino().getNome() + " (" + c.getPeso() + "km)";
            areaResultado.append(linha + "\n");
            detalhes.append(linha).append("\n");
        });

        labelDistancia.setText("💰 Custo total da AGM: " + custoTotal + " km" + tempo);
        labelStatus.setText("🌳 Prim executado - " + agm.size() + " arestas selecionadas");

        logTransaction("Prim", "AGM com " + agm.size() + " arestas, custo: " + custoTotal + "km");
        atualizarTreeResultados("Algoritmo de Prim", detalhes.toString());

        // Mostrar diálogo personalizado com resultados
        mostrarResumoPrim(agm.size(), custoTotal, tempo, cidades.size());
    }

    private void executarDijkstra() {
        animador.resetar();
        
        String origem = (String) comboOrigem.getSelectedItem();
        String destino = (String) comboDestino.getSelectedItem();
        
        if (origem.equals(destino)) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Origem e destino devem ser diferentes!", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        No cidadeOrigem = getCidadePorNome(origem);
        No cidadeDestino = getCidadePorNome(destino);

        Map<No, Integer> distancias = new HashMap<>();
        Map<No, No> anterior = new HashMap<>();
        PriorityQueue<No> pq = new PriorityQueue<>(Comparator.comparingInt(distancias::get));
        
        cidades.forEach(c -> {
            distancias.put(c, Integer.MAX_VALUE);
            anterior.put(c, null);
        });
        
        distancias.put(cidadeOrigem, 0);
        pq.add(cidadeOrigem);
        
        while(!pq.isEmpty()){
            No atual = pq.poll();
            
            if (atual == cidadeDestino) break;
            
            for(Aresta con : conexoes) {
                if (con.getOrigem() == atual) {
                    No vizinho = con.getDestino();
                    int novaDist = distancias.get(atual) + con.getPeso();
                    if (novaDist < distancias.get(vizinho)) {
                        distancias.put(vizinho, novaDist);
                        anterior.put(vizinho, atual);
                        pq.add(vizinho);
                    }
                }
            }
        }
        
        List<Aresta> caminho = new ArrayList<>();
        No atual = cidadeDestino;
        while(anterior.get(atual) != null) {
            No prev = anterior.get(atual);
            for(Aresta con : conexoes) {
                if(con.getOrigem() == prev && con.getDestino() == atual) {
                    caminho.add(con);
                    break;
                }
            }
            atual = prev;
        }
        Collections.reverse(caminho);
        
        ultimoResultado = new ArrayList<>(caminho);
        painelGrafo.setCaminhoDestacado(caminho);
        painelGrafo.iniciarAnimacao(); // 🔥 ativa partículas azuis e douradas

        
        areaResultado.setText("╔══ ALGORITMO DE DIJKSTRA ══╗\n");
        areaResultado.append("Caminho Mínimo Encontrado\n\n");
        areaResultado.append("🎯 Origem: " + origem + "\n");
        areaResultado.append("🏁 Destino: " + destino + "\n");
        areaResultado.append("═".repeat(35) + "\n\n");
        
        StringBuilder detalhes = new StringBuilder();
        int etapa = 1;
        for(Aresta c : caminho) {
            String linha = String.format("%d. %s → %s (%dkm)", 
                etapa++, c.getOrigem().getNome(), c.getDestino().getNome(), c.getPeso());
            areaResultado.append(linha + "\n");
            detalhes.append(linha).append("\n");
        }

        ConversorTempo cc = new ConversorTempo();
        int distTotal = distancias.get(cidadeDestino);
        String tempo = cc.pesoParaTempo(distTotal);

        labelDistancia.setText("🎯 Distância total: " + distTotal + " km (" + caminho.size() + " segmentos, tempo: " + tempo + ")");
        labelStatus.setText("✅ Rota ótima calculada com sucesso!");

        logTransaction("Dijkstra", origem + " → " + destino + ": " + distTotal + "km em " + caminho.size() + " segmentos");
        atualizarTreeResultados("Dijkstra: " + origem + " → " + destino, detalhes.toString());

        // Mostrar diálogo personalizado com resultados
        mostrarResumoDijkstra(origem, destino, distTotal, tempo, caminho.size());
    }
    
    private void limparResultados() {
        animador.resetar();
        animadorComboio.resetar();
        ultimoResultado = null;
        labelDistancia.setText("⏳ Aguardando cálculo...");
        areaResultado.setText("");
        painelGrafo.setCaminhoDestacado(null);
        labelStatus.setText("🔄 Visualização limpa - Sistema pronto");
        
        logTransaction("Sistema", "Visualização limpa");
    }
    
    private void executarDFS() {
        animador.resetar();

        if (comboOrigemBusca == null) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro: Combobox não inicializado!", 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        String origem = (String) comboOrigemBusca.getSelectedItem();
        
        if (origem == null || origem.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione uma cidade de origem!", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        No cidadeOrigem = getCidadePorNome(origem);
        
        if (cidadeOrigem == null) {
            JOptionPane.showMessageDialog(this, 
                "❌ Cidade de origem não encontrada!", 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<No> ordemVisita = AlgoritmoBusca.executarDFSCompleto(cidades, conexoes, cidadeOrigem);

        if (ordemVisita.isEmpty()) {
            areaResultado.setText("❌ Erro ao executar DFS");
            labelDistancia.setText("⚠️ Nenhum resultado");
            painelGrafo.setCaminhoDestacado(null);
            labelStatus.setText("❌ DFS falhou");
            return;
        }

        List<Aresta> caminhoVisual = construirArvoreVisita(ordemVisita, conexoes);
        ultimoResultado = caminhoVisual;
        painelGrafo.setCaminhoDestacado(caminhoVisual);
        painelGrafo.iniciarAnimacao();

        areaResultado.setText("╔══ BUSCA EM PROFUNDIDADE (DFS) ══╗\n\n");
        areaResultado.append("🎯 Origem: " + origem + "\n");
        areaResultado.append("📊 Estratégia: Profundidade (Stack/Recursão)\n");
        areaResultado.append("🔤 Critério: Ordem Alfabética\n");
        areaResultado.append("═".repeat(40) + "\n\n");
        areaResultado.append("Ordem de visitação:\n");
        
        StringBuilder detalhes = new StringBuilder();
        for (int i = 0; i < ordemVisita.size(); i++) {
            String linha = String.format("%d. %s", i + 1, ordemVisita.get(i).getNome());
            areaResultado.append(linha + "\n");
            detalhes.append(linha).append("\n");
        }

        labelDistancia.setText("🧭 Total de nós visitados: " + ordemVisita.size() + " de " + cidades.size());
        labelStatus.setText("✅ DFS executado - Origem: " + origem);

        logTransaction("DFS", "Origem: " + origem + ", visitados: " + ordemVisita.size() + " nós");
        atualizarTreeResultados("DFS - " + origem, detalhes.toString());

        // Mostrar diálogo personalizado com resultados
        mostrarResumoBusca("DFS", "Busca em Profundidade", origem, ordemVisita.size(), cidades.size());
    }

    private void executarBFS() {
        animador.resetar();

        if (comboOrigemBusca == null) {
            JOptionPane.showMessageDialog(this, 
                "❌ Erro: Combobox não inicializado!", 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        String origem = (String) comboOrigemBusca.getSelectedItem();
        
        if (origem == null || origem.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "⚠️ Selecione uma cidade de origem!", 
                "Aviso", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        No cidadeOrigem = getCidadePorNome(origem);
        
        if (cidadeOrigem == null) {
            JOptionPane.showMessageDialog(this, 
                "❌ Cidade de origem não encontrada!", 
                "Erro", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<No> ordemVisita = AlgoritmoBusca.executarBFSCompleto(cidades, conexoes, cidadeOrigem);

        if (ordemVisita.isEmpty()) {
            areaResultado.setText("❌ Erro ao executar BFS");
            labelDistancia.setText("⚠️ Nenhum resultado");
            painelGrafo.setCaminhoDestacado(null);
            labelStatus.setText("❌ BFS falhou");
            return;
        }

        List<Aresta> caminhoVisual = construirArvoreVisita(ordemVisita, conexoes);
        ultimoResultado = caminhoVisual;
        painelGrafo.setCaminhoDestacado(caminhoVisual);
        painelGrafo.iniciarAnimacao();

        areaResultado.setText("╔══ BUSCA EM LARGURA (BFS) ══╗\n\n");
        areaResultado.append("🎯 Origem: " + origem + "\n");
        areaResultado.append("📊 Estratégia: Largura (Queue/Fila)\n");
        areaResultado.append("🔤 Critério: Ordem Alfabética\n");
        areaResultado.append("═".repeat(40) + "\n\n");
        areaResultado.append("Ordem de visitação (nível a nível):\n");
        
        StringBuilder detalhes = new StringBuilder();
        for (int i = 0; i < ordemVisita.size(); i++) {
            String linha = String.format("%d. %s", i + 1, ordemVisita.get(i).getNome());
            areaResultado.append(linha + "\n");
            detalhes.append(linha).append("\n");
        }

        labelDistancia.setText("🚀 Total de nós visitados: " + ordemVisita.size() + " de " + cidades.size());
        labelStatus.setText("✅ BFS executado - Origem: " + origem);

        logTransaction("BFS", "Origem: " + origem + ", visitados: " + ordemVisita.size() + " nós");
        atualizarTreeResultados("BFS - " + origem, detalhes.toString());

        // Mostrar diálogo personalizado com resultados
        mostrarResumoBusca("BFS", "Busca em Largura", origem, ordemVisita.size(), cidades.size());
    }

    public AnimadorComboio getAnimadorComboio() {
        return animadorComboio;
    }

    private List<Aresta> construirArvoreVisita(List<No> ordemVisita, List<Aresta> conexoes) {
        List<Aresta> arvore = new ArrayList<>();
        Set<No> visitados = new HashSet<>();
        
        if (ordemVisita.isEmpty()) return arvore;
        
        visitados.add(ordemVisita.get(0));
        
        for (int i = 1; i < ordemVisita.size(); i++) {
            No noAtual = ordemVisita.get(i);
            
            for (Aresta aresta : conexoes) {
                if (visitados.contains(aresta.getOrigem()) && aresta.getDestino().equals(noAtual)) {
                    arvore.add(aresta);
                    visitados.add(noAtual);
                    break;
                }
            }
        }
        
        return arvore;
    }

    /**
     * Pinta um fundo gradiente com cantos arredondados.
     */
    private void pintarFundoGradiente(Graphics2D g2d, JComponent comp, Color cor1, Color cor2) {
        int w = comp.getWidth();
        int h = comp.getHeight();
        GradientPaint gp = new GradientPaint(0, 0, cor1, w, h, cor2);
        g2d.setPaint(gp);
        g2d.fillRoundRect(0, 0, w, h, 20, 20);
    }

    /**
     * Adiciona sombra leve ao redor de um componente.
     */
    private void desenharSombra(Graphics2D g2d, JComponent comp) {
        int w = comp.getWidth();
        int h = comp.getHeight();
        g2d.setColor(new Color(0, 0, 0, 25));
        g2d.fillRoundRect(5, 5, w - 10, h - 10, 20, 20);
    }

    /**
     * Mostra diálogo personalizado com resultados do Dijkstra
     */
    private void mostrarResumoDijkstra(String origem, String destino, int distanciaTotal, String tempo, int segmentos) {
        JPanel painelResumo = new JPanel();
        painelResumo.setLayout(new BoxLayout(painelResumo, BoxLayout.Y_AXIS));
        painelResumo.setBackground(new Color(240, 248, 255));
        painelResumo.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel labelTitulo = new JLabel("🎯 Caminho Mais Curto Encontrado!");
        labelTitulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 18));
        labelTitulo.setForeground(new Color(30, 90, 140));
        labelTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelResumo.add(labelTitulo);
        painelResumo.add(Box.createRigidArea(new Dimension(0, 15)));

        javax.swing.JSeparator separador = new javax.swing.JSeparator();
        separador.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        painelResumo.add(separador);
        painelResumo.add(Box.createRigidArea(new Dimension(0, 15)));

        adicionarInfoLinhaDialogo(painelResumo, "🎯 Origem:", origem);
        adicionarInfoLinhaDialogo(painelResumo, "🏁 Destino:", destino);
        adicionarInfoLinhaDialogo(painelResumo, "📏 Distância total:", distanciaTotal + " km");
        adicionarInfoLinhaDialogo(painelResumo, "🔗 Segmentos:", String.valueOf(segmentos));
        adicionarInfoLinhaDialogo(painelResumo, "⏱️ Tempo estimado:", tempo);

        JOptionPane.showMessageDialog(this, painelResumo, "Resultado - Algoritmo de Dijkstra", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Mostra diálogo personalizado com resultados do Kruskal
     */
    private void mostrarResumoKruskal(int numArestas, int custoTotal, String tempo, int numCidades) {
        JPanel painelResumo = new JPanel();
        painelResumo.setLayout(new BoxLayout(painelResumo, BoxLayout.Y_AXIS));
        painelResumo.setBackground(new Color(240, 255, 240));
        painelResumo.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel labelTitulo = new JLabel("🌳 Árvore Geradora Mínima - Kruskal");
        labelTitulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 18));
        labelTitulo.setForeground(new Color(34, 139, 34));
        labelTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelResumo.add(labelTitulo);
        painelResumo.add(Box.createRigidArea(new Dimension(0, 15)));

        javax.swing.JSeparator separador = new javax.swing.JSeparator();
        separador.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        painelResumo.add(separador);
        painelResumo.add(Box.createRigidArea(new Dimension(0, 15)));

        adicionarInfoLinhaDialogo(painelResumo, "📍 Cidades conectadas:", String.valueOf(numCidades));
        adicionarInfoLinhaDialogo(painelResumo, "🔗 Arestas selecionadas:", String.valueOf(numArestas));
        adicionarInfoLinhaDialogo(painelResumo, "💰 Custo total da AGM:", custoTotal + " km");
        adicionarInfoLinhaDialogo(painelResumo, "⏱️ Tempo total:", tempo);

        JOptionPane.showMessageDialog(this, painelResumo, "Resultado - Algoritmo de Kruskal", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Mostra diálogo personalizado com resultados do Prim
     */
    private void mostrarResumoPrim(int numArestas, int custoTotal, String tempo, int numCidades) {
        JPanel painelResumo = new JPanel();
        painelResumo.setLayout(new BoxLayout(painelResumo, BoxLayout.Y_AXIS));
        painelResumo.setBackground(new Color(240, 255, 240));
        painelResumo.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel labelTitulo = new JLabel("🌳 Árvore Geradora Mínima - Prim");
        labelTitulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 18));
        labelTitulo.setForeground(new Color(34, 139, 34));
        labelTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelResumo.add(labelTitulo);
        painelResumo.add(Box.createRigidArea(new Dimension(0, 15)));

        javax.swing.JSeparator separador = new javax.swing.JSeparator();
        separador.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        painelResumo.add(separador);
        painelResumo.add(Box.createRigidArea(new Dimension(0, 15)));

        adicionarInfoLinhaDialogo(painelResumo, "📍 Cidades conectadas:", String.valueOf(numCidades));
        adicionarInfoLinhaDialogo(painelResumo, "🔗 Arestas selecionadas:", String.valueOf(numArestas));
        adicionarInfoLinhaDialogo(painelResumo, "💰 Custo total da AGM:", custoTotal + " km");
        adicionarInfoLinhaDialogo(painelResumo, "⏱️ Tempo total:", tempo);

        JOptionPane.showMessageDialog(this, painelResumo, "Resultado - Algoritmo de Prim", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Mostra diálogo personalizado com resultados de BFS/DFS
     */
    private void mostrarResumoBusca(String algoritmo, String nomeCompleto, String origem, int nosVisitados, int totalNos) {
        JPanel painelResumo = new JPanel();
        painelResumo.setLayout(new BoxLayout(painelResumo, BoxLayout.Y_AXIS));
        painelResumo.setBackground(new Color(255, 248, 240));
        painelResumo.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        String emoji = algoritmo.equals("BFS") ? "🌊" : "🌲";
        JLabel labelTitulo = new JLabel(emoji + " " + nomeCompleto + " Concluída!");
        labelTitulo.setFont(new Font("Segoe UI Emoji", Font.BOLD, 18));
        labelTitulo.setForeground(new Color(184, 134, 11));
        labelTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        painelResumo.add(labelTitulo);
        painelResumo.add(Box.createRigidArea(new Dimension(0, 15)));

        javax.swing.JSeparator separador = new javax.swing.JSeparator();
        separador.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        painelResumo.add(separador);
        painelResumo.add(Box.createRigidArea(new Dimension(0, 15)));

        adicionarInfoLinhaDialogo(painelResumo, "🎯 Cidade de origem:", origem);
        adicionarInfoLinhaDialogo(painelResumo, "📊 Estratégia:", algoritmo.equals("BFS") ? "Largura (Queue)" : "Profundidade (Stack)");
        adicionarInfoLinhaDialogo(painelResumo, "✅ Nós visitados:", nosVisitados + " de " + totalNos);
        double percentual = (nosVisitados * 100.0) / totalNos;
        adicionarInfoLinhaDialogo(painelResumo, "📈 Cobertura:", String.format("%.1f%%", percentual));

        JOptionPane.showMessageDialog(this, painelResumo, "Resultado - " + nomeCompleto + " (" + algoritmo + ")", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Adiciona uma linha de informação ao painel de diálogo
     */
    private void adicionarInfoLinhaDialogo(JPanel painel, String label, String valor) {
        JPanel linhaPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 5));
        linhaPanel.setBackground(painel.getBackground());
        linhaPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel labelTexto = new JLabel(label);
        labelTexto.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        labelTexto.setForeground(new Color(60, 60, 60));

        JLabel labelValor = new JLabel("  " + valor);
        labelValor.setFont(new Font("Segoe UI Emoji", Font.BOLD, 14));
        labelValor.setForeground(new Color(30, 90, 140));

        linhaPanel.add(labelTexto);
        linhaPanel.add(labelValor);
        painel.add(linhaPanel);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> new PainelPrincipal());
    }
}