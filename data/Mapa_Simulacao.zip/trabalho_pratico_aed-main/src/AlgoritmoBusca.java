import java.util.*;
import models.No;
import models.Aresta;

public class AlgoritmoBusca {
    
    /**
     * DFS (Depth-First Search) - encontrar caminho entre dois nós
     */
    public static List<Aresta> executarDFS(List<No> cidades, List<Aresta> conexoes, No origem, No destino) {
        Map<No, Boolean> visitados = new HashMap<>();
        Map<No, No> anterior = new HashMap<>();
        
        for (No cidade : cidades) {
            visitados.put(cidade, false);
            anterior.put(cidade, null);
        }
        
        boolean encontrado = dfsRecursivo(origem, destino, conexoes, visitados, anterior);
        
        if (!encontrado) {
            return new ArrayList<>();
        }
        
        return reconstruirCaminho(origem, destino, anterior, conexoes);
    }
    
    private static boolean dfsRecursivo(No atual, No destino, List<Aresta> conexoes, 
                                        Map<No, Boolean> visitados, Map<No, No> anterior) {
        visitados.put(atual, true);
        
        if (atual.equals(destino)) {
            return true;
        }
        
        for (Aresta aresta : conexoes) {
            if (aresta.getOrigem().equals(atual)) {
                No vizinho = aresta.getDestino();
                
                if (!visitados.get(vizinho)) {
                    anterior.put(vizinho, atual);
                    if (dfsRecursivo(vizinho, destino, conexoes, visitados, anterior)) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * BFS (Breadth-First Search) - encontrar caminho entre dois nós
     */
    public static List<Aresta> executarBFS(List<No> cidades, List<Aresta> conexoes, No origem, No destino) {
        Map<No, Boolean> visitados = new HashMap<>();
        Map<No, No> anterior = new HashMap<>();
        Queue<No> fila = new LinkedList<>();
        
        for (No cidade : cidades) {
            visitados.put(cidade, false);
            anterior.put(cidade, null);
        }
        
        visitados.put(origem, true);
        fila.add(origem);
        boolean encontrado = false;
        
        while (!fila.isEmpty() && !encontrado) {
            No atual = fila.poll();
            
            if (atual.equals(destino)) {
                encontrado = true;
                break;
            }
            
            for (Aresta aresta : conexoes) {
                if (aresta.getOrigem().equals(atual)) {
                    No vizinho = aresta.getDestino();
                    
                    if (!visitados.get(vizinho)) {
                        visitados.put(vizinho, true);
                        anterior.put(vizinho, atual);
                        fila.add(vizinho);
                    }
                }
            }
        }
        
        if (!encontrado) {
            return new ArrayList<>();
        }
        
        return reconstruirCaminho(origem, destino, anterior, conexoes);
    }
    
    /**
     * DFS COMPLETO - percorre todo o grafo a partir da origem
     * Vizinhos visitados em ORDEM ALFABÉTICA
     */
    public static List<No> executarDFSCompleto(List<No> cidades, List<Aresta> conexoes, No origem) {
        Map<No, Boolean> visitados = new HashMap<>();
        List<No> ordemVisita = new ArrayList<>();
        
        for (No cidade : cidades) {
            visitados.put(cidade, false);
        }
        
        dfsCompletoRecursivo(origem, conexoes, visitados, ordemVisita);
        
        return ordemVisita;
    }
    
    private static void dfsCompletoRecursivo(No atual, List<Aresta> conexoes, 
                                             Map<No, Boolean> visitados, List<No> ordemVisita) {
        visitados.put(atual, true);
        ordemVisita.add(atual);
        
        // Obter vizinhos
        List<No> vizinhos = new ArrayList<>();
        for (Aresta aresta : conexoes) {
            if (aresta.getOrigem().equals(atual)) {
                vizinhos.add(aresta.getDestino());
            }
        }
        
        // ORDENAR ALFABETICAMENTE (critério definido)
        vizinhos.sort(Comparator.comparing(No::getNome));
        
        // Explorar vizinhos ordenados
        for (No vizinho : vizinhos) {
            if (!visitados.get(vizinho)) {
                dfsCompletoRecursivo(vizinho, conexoes, visitados, ordemVisita);
            }
        }
    }
    
    /**
     * BFS COMPLETO - percorre todo o grafo a partir da origem
     * Vizinhos visitados em ORDEM ALFABÉTICA
     */
    public static List<No> executarBFSCompleto(List<No> cidades, List<Aresta> conexoes, No origem) {
        Map<No, Boolean> visitados = new HashMap<>();
        Queue<No> fila = new LinkedList<>();
        List<No> ordemVisita = new ArrayList<>();
        
        for (No cidade : cidades) {
            visitados.put(cidade, false);
        }
        
        visitados.put(origem, true);
        fila.add(origem);
        ordemVisita.add(origem);
        
        while (!fila.isEmpty()) {
            No atual = fila.poll();
            
            // Obter vizinhos
            List<No> vizinhos = new ArrayList<>();
            for (Aresta aresta : conexoes) {
                if (aresta.getOrigem().equals(atual)) {
                    vizinhos.add(aresta.getDestino());
                }
            }
            
            // ORDENAR ALFABETICAMENTE (critério definido)
            vizinhos.sort(Comparator.comparing(No::getNome));
            
            // Explorar vizinhos ordenados
            for (No vizinho : vizinhos) {
                if (!visitados.get(vizinho)) {
                    visitados.put(vizinho, true);
                    fila.add(vizinho);
                    ordemVisita.add(vizinho);
                }
            }
        }
        
        return ordemVisita;
    }
    
    /**
     * DFS usando matriz de adjacência
     */
    public static List<Aresta> executarDFSMatriz(int[][] matriz, List<No> cidades, 
                                                  int indiceOrigem, int indiceDestino) {
        boolean[] visitados = new boolean[matriz.length];
        int[] anterior = new int[matriz.length];
        Arrays.fill(anterior, -1);
        
        boolean encontrado = dfsMatrizRecursivo(matriz, indiceOrigem, indiceDestino, visitados, anterior);
        
        if (!encontrado) {
            return new ArrayList<>();
        }
        
        return reconstruirCaminhoMatriz(indiceOrigem, indiceDestino, anterior, cidades, matriz);
    }
    
    private static boolean dfsMatrizRecursivo(int[][] matriz, int atual, int destino, 
                                              boolean[] visitados, int[] anterior) {
        visitados[atual] = true;
        
        if (atual == destino) {
            return true;
        }
        
        for (int i = 0; i < matriz.length; i++) {
            if (matriz[atual][i] > 0 && !visitados[i]) {
                anterior[i] = atual;
                if (dfsMatrizRecursivo(matriz, i, destino, visitados, anterior)) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * BFS usando matriz de adjacência
     */
    public static List<Aresta> executarBFSMatriz(int[][] matriz, List<No> cidades, 
                                                  int indiceOrigem, int indiceDestino) {
        boolean[] visitados = new boolean[matriz.length];
        int[] anterior = new int[matriz.length];
        Arrays.fill(anterior, -1);
        Queue<Integer> fila = new LinkedList<>();
        
        visitados[indiceOrigem] = true;
        fila.add(indiceOrigem);
        boolean encontrado = false;
        
        while (!fila.isEmpty() && !encontrado) {
            int atual = fila.poll();
            
            if (atual == indiceDestino) {
                encontrado = true;
                break;
            }
            
            for (int i = 0; i < matriz.length; i++) {
                if (matriz[atual][i] > 0 && !visitados[i]) {
                    visitados[i] = true;
                    anterior[i] = atual;
                    fila.add(i);
                }
            }
        }
        
        if (!encontrado) {
            return new ArrayList<>();
        }
        
        return reconstruirCaminhoMatriz(indiceOrigem, indiceDestino, anterior, cidades, matriz);
    }
    
    private static List<Aresta> reconstruirCaminho(No origem, No destino, 
                                                    Map<No, No> anterior, List<Aresta> conexoes) {
        List<Aresta> caminho = new ArrayList<>();
        No atual = destino;
        
        while (anterior.get(atual) != null) {
            No prev = anterior.get(atual);
            
            for (Aresta aresta : conexoes) {
                if (aresta.getOrigem().equals(prev) && aresta.getDestino().equals(atual)) {
                    caminho.add(aresta);
                    break;
                }
            }
            
            atual = prev;
        }
        
        Collections.reverse(caminho);
        return caminho;
    }
    
    private static List<Aresta> reconstruirCaminhoMatriz(int origem, int destino, 
                                                          int[] anterior, List<No> cidades, int[][] matriz) {
        List<Aresta> caminho = new ArrayList<>();
        List<Integer> indices = new ArrayList<>();
        
        int atual = destino;
        while (atual != origem) {
            indices.add(atual);
            atual = anterior[atual];
        }
        indices.add(origem);
        Collections.reverse(indices);
        
        for (int i = 0; i < indices.size() - 1; i++) {
            int idx1 = indices.get(i);
            int idx2 = indices.get(i + 1);
            No n1 = cidades.get(idx1);
            No n2 = cidades.get(idx2);
            int peso = matriz[idx1][idx2];
            
            caminho.add(new Aresta(n1, n2, peso));
        }
        
        return caminho;
    }
}