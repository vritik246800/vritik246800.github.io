import models.Grafo;
import models.No;
import javax.swing.*;


public class Main
{
	public static void main(String[] args)
	{
		// 1. Criar o Grafo (carregar dados da Ucrânia)
        Grafo grafo = new Grafo();
        // ... Lógica para carregar nós e arestas (simulação) ...
        // Exemplo:
        No kiev = new No("Kiev", 100, 100);
        No lviv = new No("Lviv", 50, 150);
        grafo.addNo(kiev);
        grafo.addNo(lviv);
        grafo.addAresta("Kiev", "Lviv", 500);

		// 2. Chamar o Painel Principal (Interface Gráfica)
        // Isso deve inicializar a janela, desenhar o grafo e adicionar os controles
        // (ComboBox/Cliques para seleção de origem/destino e o Botão).
        /*javax.swing.SwingUtilities.invokeLater(() -> {
            PainelGrafo painel = new PainelGrafo(grafo);
            // PainelGrafo deve conter o código para a interface
        });*/

		System.out.println("Hello Guys!\nVamos Trabalhar");
		System.out.println("Como diz docente: Qualquer coisa, estou na area! ^_^");
	}
}