import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import models.No;
import models.Aresta;

public class Lista_Adjacencia_Janela extends JFrame {
    
    private static class ArestaInfo {
        No destino;
        double peso;
        
        ArestaInfo(No destino, double peso) {
            this.destino = destino;
            this.peso = peso;
        }
    }
    
    private Map<No, List<ArestaInfo>> adjacencias;
    
    public Lista_Adjacencia_Janela(List<No> nos, List<Aresta> arestas) {
        setTitle("Lista de Adjacências");
        setSize(1000, 700);
        setResizable(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Construir estrutura de adjacências
        adjacencias = new LinkedHashMap<>();
        for (No no : nos) {
            adjacencias.put(no, new ArrayList<>());
        }
        
        for (Aresta aresta : arestas) {
            adjacencias.get(aresta.getOrigem()).add(
                new ArestaInfo(aresta.getDestino(), aresta.getPeso())
            );
        }
        
        // Painel principal com renderização customizada
        JPanel painelPrincipal = new PainelListaAdjacencia();
        
        JScrollPane scrollPane = new JScrollPane(painelPrincipal);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        
        add(scrollPane);
        setVisible(true);
    }
    
    private class PainelListaAdjacencia extends JPanel {
        private static final int MARGEM = 40;
        private static final int ESPACAMENTO_LINHA = 110;
        private static final int LARGURA_NO = 120;
        private static final int ALTURA_NO = 45;
        private static final int ESPACO_ENTRE_NOS = 50;
        
        public PainelListaAdjacencia() {
            setBackground(new Color(250, 250, 252));
            
            // Calcular largura necessária
            int larguraMaxima = calcularLarguraMaxima();
            setPreferredSize(new Dimension(
                Math.max(950, larguraMaxima + MARGEM * 2), 
                MARGEM * 2 + adjacencias.size() * ESPACAMENTO_LINHA
            ));
        }
        
        private int calcularLarguraMaxima() {
            int maxLargura = 0;
            for (List<ArestaInfo> adjacentes : adjacencias.values()) {
                int larguraLinha = MARGEM + LARGURA_NO + 100 + 
                                   adjacentes.size() * (LARGURA_NO + ESPACO_ENTRE_NOS);
                maxLargura = Math.max(maxLargura, larguraLinha);
            }
            return maxLargura;
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            
            // Antialiasing
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            
            int y = MARGEM + ALTURA_NO/2;
            int linha = 0;
            
            for (Map.Entry<No, List<ArestaInfo>> entrada : adjacencias.entrySet()) {
                desenharLinhaAdjacencia(g2d, entrada.getKey(), entrada.getValue(), y, linha % 2 == 0);
                y += ESPACAMENTO_LINHA;
                linha++;
            }
        }
        
        private void desenharLinhaAdjacencia(Graphics2D g2d, No origem, List<ArestaInfo> adjacentes, int y, boolean alternar) {
            int xOrigem = MARGEM;
            
            // Fundo alternado
            if (alternar) {
                g2d.setColor(new Color(245, 247, 250, 100));
                int larguraFundo = calcularLarguraLinha(adjacentes);
                g2d.fillRoundRect(15, y - ALTURA_NO/2 - 15, larguraFundo, ESPACAMENTO_LINHA - 20, 15, 15);
            }
            
            // Nó de origem
            desenharNo(g2d, origem, xOrigem, y, true);
            
            // Posição após o nó de origem
            int xProximo = xOrigem + LARGURA_NO + 60;
            
            if (adjacentes.isEmpty()) {
                // Seta para vazio
                desenharSeta(g2d, xOrigem + LARGURA_NO + 20, y, 30);
                
                g2d.setFont(new Font("Segoe UI", Font.ITALIC, 16));
                g2d.setColor(new Color(150, 150, 150));
                g2d.drawString("∅ (vazio)", xProximo, y + 5);
            } else {
                // Desenhar conexões e adjacentes
                for (int i = 0; i < adjacentes.size(); i++) {
                    ArestaInfo info = adjacentes.get(i);
                    
                    int xAdjacente = xProximo + i * (LARGURA_NO + ESPACO_ENTRE_NOS);
                    
                    // Linha conectora
                    int xInicioLinha = (i == 0) ? xOrigem + LARGURA_NO : xProximo + (i-1) * (LARGURA_NO + ESPACO_ENTRE_NOS) + LARGURA_NO;
                    int xFimLinha = xAdjacente;
                    
                    desenharConexao(g2d, xInicioLinha, y, xFimLinha, y, info.peso);
                    
                    // Nó adjacente
                    desenharNo(g2d, info.destino, xAdjacente, y, false);
                }
            }
        }
        
        private int calcularLarguraLinha(List<ArestaInfo> adjacentes) {
            if (adjacentes.isEmpty()) {
                return MARGEM + LARGURA_NO + 200;
            }
            return MARGEM + LARGURA_NO + 100 + adjacentes.size() * (LARGURA_NO + ESPACO_ENTRE_NOS);
        }
        
        private void desenharConexao(Graphics2D g2d, int x1, int y1, int x2, int y2, double peso) {
            // Linha conectora
            g2d.setColor(new Color(52, 73, 94));
            g2d.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2d.drawLine(x1 + 10, y1, x2 - 10, y2);
            
            // Seta
            int xSeta = x2 - 10;
            int[] xPoints = {xSeta, xSeta - 8, xSeta - 8};
            int[] yPoints = {y2, y2 - 5, y2 + 5};
            g2d.fillPolygon(xPoints, yPoints, 3);
            
            g2d.setStroke(new BasicStroke(1));
            
            // Peso da aresta
            String textoPeso = String.format("%.1f", peso);
            g2d.setFont(new Font("Segoe UI", Font.BOLD, 12));
            
            FontMetrics fm = g2d.getFontMetrics();
            int larguraPeso = fm.stringWidth(textoPeso);
            int alturaPeso = fm.getHeight();
            
            int xPeso = (x1 + x2) / 2;
            int yPeso = y1 - 15;
            
            // Fundo do peso
            g2d.setColor(new Color(231, 76, 60));
            g2d.fillRoundRect(xPeso - larguraPeso/2 - 6, yPeso - alturaPeso/2 - 2, 
                             larguraPeso + 12, alturaPeso, 12, 12);
            
            // Texto do peso
            g2d.setColor(Color.WHITE);
            g2d.drawString(textoPeso, xPeso - larguraPeso/2, yPeso + fm.getAscent()/2 - 2);
        }
        
        private void desenharNo(Graphics2D g2d, No no, int x, int y, boolean origem) {
            int largura = LARGURA_NO;
            int altura = ALTURA_NO;
            
            // Sombra
            g2d.setColor(new Color(0, 0, 0, 40));
            g2d.fillRoundRect(x + 3, y - altura/2 + 3, largura, altura, 12, 12);
            
            // Preenchimento branco
            g2d.setColor(Color.WHITE);
            g2d.fillRoundRect(x, y - altura/2, largura, altura, 12, 12);
            
            // Borda preta
            g2d.setColor(Color.BLACK);
            g2d.setStroke(new BasicStroke(origem ? 3f : 2f));
            g2d.drawRoundRect(x, y - altura/2, largura, altura, 12, 12);
            g2d.setStroke(new BasicStroke(1));
            
            // Nome do nó
            String nome = extrairNome(no.getNome());
            g2d.setFont(new Font("Segoe UI", Font.BOLD, origem ? 15 : 13));
            g2d.setColor(Color.BLACK);
            
            FontMetrics fm = g2d.getFontMetrics();
            int larguraTexto = fm.stringWidth(nome);
            int alturaTexto = fm.getAscent();
            
            // Centralizar texto
            int xTexto = x + (largura - larguraTexto) / 2;
            int yTexto = y + (alturaTexto - fm.getDescent()) / 2;
            
            g2d.drawString(nome, xTexto, yTexto);
        }
        
        private void desenharSeta(Graphics2D g2d, int x, int y, int comprimento) {
            g2d.setColor(new Color(149, 165, 166));
            g2d.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            
            g2d.drawLine(x, y, x + comprimento, y);
            
            int[] xPoints = {x + comprimento, x + comprimento - 6, x + comprimento - 6};
            int[] yPoints = {y, y - 4, y + 4};
            g2d.fillPolygon(xPoints, yPoints, 3);
            
            g2d.setStroke(new BasicStroke(1));
        }
    }
    
    private String extrairNome(String texto) {
        if (texto.contains("|")) {
            return texto.substring(0, texto.indexOf("|"));
        }
        return texto;
    }
}