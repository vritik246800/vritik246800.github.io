package models;
import java.util.*;

public class Grafo 
{
    private int[][] matrizAdj;
    private HashMap<String, ArrayList<Aresta>> listasAdj;
    private HashMap<String, No> nos;
    private ArrayList<No> nosOrdenados;
    
    public Grafo() 
    {
        this.nos = new HashMap<>();
        this.listasAdj = new HashMap<>();
        this.nosOrdenados = new ArrayList<>();
    }
    
    public void addNo(No no) 
    {
        String nome = no.getNome();
        if(nos.containsKey(nome)) return;
        
        nos.put(nome, no);
        nosOrdenados.add(no);
        listasAdj.put(nome, new ArrayList<>());
        
        redimensionarMatriz();
    }
    
    public void addAresta(String origem, String destino, int peso) 
    {
        if(!nos.containsKey(origem) || !nos.containsKey(destino)) 
        	return;
        
        No noOrigem = nos.get(origem);
        No noDestino = nos.get(destino);
        
        int idxOrigem = nosOrdenados.indexOf(noOrigem);
        int idxDestino = nosOrdenados.indexOf(noDestino);
        
        matrizAdj[idxOrigem][idxDestino] = peso;
        matrizAdj[idxDestino][idxOrigem] = peso;
        
        listasAdj.get(origem).add(new Aresta(noOrigem, noDestino, peso));
        listasAdj.get(destino).add(new Aresta(noDestino, noOrigem, peso));
    }
    
    private void redimensionarMatriz() 
    {
        int n = nosOrdenados.size();        // quantos nós existem AGORA
        int[][] novaMatriz = new int[n][n]; // criar matriz maior
        
        if(matrizAdj != null) // se já existia matriz antiga
        {  
            // COPIAR valores antigos para a nova
            for(int i = 0; i < Math.min(n, matrizAdj.length); i++) 
                for(int j = 0; j < Math.min(n, matrizAdj.length); j++) 
                    novaMatriz[i][j] = matrizAdj[i][j];
        } 
        matrizAdj = novaMatriz; // substituir antiga pela nova
    }
    
    public void removeNo(String nome) 
    {
        if(!nos.containsKey(nome)) return;
        
        No noRemovido = nos.get(nome);
        
        // Remover arestas conectadas a este nó
        ArrayList<String> chavesNos = new ArrayList<>(listasAdj.keySet());
        for(int i = 0; i < chavesNos.size(); i++) {
            String chave = chavesNos.get(i);
            ArrayList<Aresta> arestas = listasAdj.get(chave);
            
            for(int j = arestas.size() - 1; j >= 0; j--) {
                Aresta a = arestas.get(j);
                if(a.getOrigem().equals(noRemovido) || a.getDestino().equals(noRemovido)) {
                    arestas.remove(j);
                }
            }
        }
        
        nos.remove(nome);
        listasAdj.remove(nome);
        nosOrdenados.remove(noRemovido);
        
        reconstruirMatriz();
    }
    
    public void removeAresta(String origem, String destino) 
    {
        if(!nos.containsKey(origem) || !nos.containsKey(destino)) 
        	return;
        
        No noOrigem = nos.get(origem);
        No noDestino = nos.get(destino);
        
        int idxOrigem = nosOrdenados.indexOf(noOrigem);
        int idxDestino = nosOrdenados.indexOf(noDestino);
        
        matrizAdj[idxOrigem][idxDestino] = 0;
        matrizAdj[idxDestino][idxOrigem] = 0;
        
        ArrayList<Aresta> arestasOrigem = listasAdj.get(origem);
        for(int i = arestasOrigem.size() - 1; i >= 0; i--) 
            if(arestasOrigem.get(i).getDestino().equals(noDestino)) 
                arestasOrigem.remove(i);
        
        ArrayList<Aresta> arestasDestino = listasAdj.get(destino);
        for(int i = arestasDestino.size() - 1; i >= 0; i--) 
            if(arestasDestino.get(i).getDestino().equals(noOrigem)) 
                arestasDestino.remove(i);
    }
    
    private void reconstruirMatriz() 
    {
        int n = nosOrdenados.size();
        matrizAdj = new int[n][n];
        
        ArrayList<String> chavesNos = new ArrayList<>(listasAdj.keySet());
        for(int i = 0; i < chavesNos.size(); i++) 
        {
            String nomeNo = chavesNos.get(i);
            No origem = nos.get(nomeNo);
            int idxOrigem = nosOrdenados.indexOf(origem);
            
            ArrayList<Aresta> arestas = listasAdj.get(nomeNo);
            for(int j = 0; j < arestas.size(); j++) 
            {
                Aresta aresta = arestas.get(j);
                int idxDestino = nosOrdenados.indexOf(aresta.getDestino());
                matrizAdj[idxOrigem][idxDestino] = aresta.getPeso();
            }
        }
    }
    
    
    public HashMap<String, No> getNos() { return nos; }
    public ArrayList<No> getNosOrdenados() { return nosOrdenados; }
    public int[][] getMatrizAdj() { return matrizAdj; }
    public HashMap<String, ArrayList<Aresta>> getListasAdj() { return listasAdj; }
}