package models;

public class Aresta 
{
    public No origem;
    public No destino;
    public int peso;
    
    public Aresta(No origem, No destino, int peso) 
    {
        this.origem = origem;
        this.destino = destino;
        this.peso = peso;
    }
    
    public No getOrigem() { return origem; }
    public No getDestino() { return destino; }
    public int getPeso() { return peso; }
    
    public void setPeso(int peso) { this.peso = peso; }
    
    public String toString() 
    {
        return origem.getNome() + ";" + destino.getNome() + ";" + peso + "\n";
    }
}