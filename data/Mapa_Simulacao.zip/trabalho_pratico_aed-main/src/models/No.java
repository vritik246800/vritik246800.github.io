package models;

import java.awt.Point;
import java.util.Objects;

public class No 
{
    public String nome;
    private int x, y;
    public Point coordenada;
    
    public No(String nome, int x, int y) 
    {
        this.nome = nome;
        this.x = x;
        this.y = y;
    }
    
    public String getNome() { return nome; }
    public int getX() { return x; }
    public int getY() { return y; }
    
    public void setNome(String nome) { this.nome = nome; }
    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        No no = (No) obj;
        return Objects.equals(nome, no.nome);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(nome);
    }
    
    public String toString() 
    {
        return nome + ";" + x + ";" + y + "\n";
    }
}