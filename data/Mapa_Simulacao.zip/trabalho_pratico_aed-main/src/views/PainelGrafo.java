package views;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import models.*;


public class PainelGrafo extends JPanel 
{
    private List<No> cidades;
    private List<Aresta> conexoes;
    private List<Aresta> caminhoDestacado; // Para destacar o resultado dos algoritmos
    private Image imagemFundo;

    public PainelGrafo(List<No> cidades, List<Aresta> conexoes) {
        this.cidades = cidades;
        this.conexoes = conexoes;
        // Carrega a imagem de fundo do mapa
        //ImageIcon icon = new ImageIcon(getClass().getResource("image/mapa.png"));
        ImageIcon icon=new ImageIcon("/image/mapa.png");
        this.imagemFundo = icon.getImage();
    }

    public void setCaminhoDestacado(List<Aresta> caminho) {
        this.caminhoDestacado = caminho;
        repaint(); // Solicita que o painel seja redesenhado
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Desenha a imagem de fundo
        if (imagemFundo != null) {
            g2d.drawImage(imagemFundo, 0, 0, this.getWidth(), this.getHeight(), this);
        }

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Desenha todas as conexões (em cinza claro)
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.setStroke(new BasicStroke(1.5f));
//        for (Aresta conexao : conexoes) {
//            Point p1 = conexao.getOrigem().coordenada;
//            Point p2 = conexao.getDestino().coordenada;
//            g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
//        }

        // Destaca o caminho encontrado pelo algoritmo (em vermelho)
        if (caminhoDestacado != null) {
            g2d.setColor(Color.YELLOW);
            g2d.setStroke(new BasicStroke(4.0f));
//            for (Aresta conexao : caminhoDestacado) {
//                 Point p1 = conexao.getOrigem().coordenada;
//                 Point p2 = conexao.getDestino().coordenada;
//                 g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
//            }
        }

        // Desenha as cidades e seus nomes
//        for (No cidade : cidades) {
//            Point p = cidade.coordenada;
//            g2d.setColor(Color.BLUE);
//            g2d.fillOval(p.x - 7, p.y - 7, 14, 14);
//            g2d.setColor(Color.BLACK);
//            g2d.setFont(new Font("Arial", Font.BOLD, 12));
//            g2d.drawString(cidade.getNome(), p.x + 10, p.y + 5);
//        }
    }
}