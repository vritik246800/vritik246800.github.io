# TP_AED2
# Sistema de Logística Militar na Ucrânia

Sistema de otimização de rotas desenvolvido em Java Swing para calcular caminhos mínimos e árvores geradoras mínimas entre cidades ucranianas.

## Funcionalidades

### Representação de Grafos
- **Matriz de Adjacência**: Visualização tabular das conexões entre cidades com respetivas distâncias
- **Lista de Adjacências**: Lista de vizinhos diretos de cada cidade

### Algoritmos de Otimização

#### Árvore Geradora Mínima (AGM)
- **Kruskal**: Encontra a rede de conexões com menor custo total
- **Prim**: Alternativa para AGM partindo de um nó inicial

#### Caminho Mínimo
- **Dijkstra**: Calcula a rota mais curta entre duas cidades selecionadas

## Estrutura do Projeto

```
├── modelo/
│   ├── Aresta.java       # Representação de conexões entre nós
│   ├── No.java           # Representação de nós/cidades
│   └── Grafo.java        # Estrutura do grafo
├── Cidade.java           # Entidade cidade com coordenadas
├── Conexao.java          # Entidade conexão entre cidades
├── PainelGrafo.java      # Visualização gráfica do mapa
└── PainelPrincipal.java  # Interface principal
```

## Requisitos

- Java 25
- Swing (incluído no JDK)

## Como Executar

```bash
javac PainelPrincipal.java
java PainelPrincipal
```

## Utilização

### Visualizar Estrutura do Grafo
1. Clica em **Matriz de Adjacência** ou **Lista de Adjacências**
2. Observa a estrutura no painel de resultados

### Calcular Árvore Geradora Mínima
1. Clica em **Algoritmo de Kruskal** ou **Algoritmo de Prim**
2. A rede mínima aparece destacada no mapa a vermelho
3. O custo total e lista de conexões aparecem nos resultados

### Calcular Caminho Mínimo
1. Seleciona a cidade de **Origem**
2. Seleciona a cidade de **Destino**
3. Clica em **Calcular Rota (Dijkstra)**
4. O caminho mais curto aparece destacado no mapa
5. A distância total e rota detalhada aparecem nos resultados

### Limpar Visualização
Clica em **Limpar Visualização** para remover destaques do mapa

## Cidades Incluídas

- Kyiv (capital)
- Kharkiv
- Dnipro
- Odesa
- Donetsk
- Zaporizhzhya
- Kherson
- Lviv
- Poltava
- Chernihiv
- Sumy
- Zhitomyr
- Vinnytsa
- Mykolaiv
- Kropyvnitskyi
- Luhansk

## Detalhes Técnicos

### Complexidade dos Algoritmos
- **Kruskal**: O(E log E) onde E é o número de arestas
- **Prim**: O(E log V) onde V é o número de vértices
- **Dijkstra**: O((V + E) log V) com priority queue

### Representações
- **Matriz de Adjacência**: O(V²) espaço, O(1) consulta de aresta
- **Lista de Adjacências**: O(V + E) espaço, O(grau) consulta

## Características da Interface

- Design moderno com paleta de cores profissional
- Visualização gráfica do mapa com cidades e conexões
- Destaque visual dos resultados calculados
- Área de resultados com detalhes completos
- Navegação intuitiva por secções organizadas

## Melhorias Futuras

- [ ] Implementar A* para heurísticas de distância euclidiana
- [ ] Adicionar Bellman-Ford para grafos com pesos negativos
- [ ] Permitir importação de dados de ficheiros externos
- [ ] Exportar resultados para CSV/PDF
- [ ] Modo de edição para adicionar/remover cidades
- [ ] Animação dos algoritmos passo a passo

## Autor

**Vritik Valabdas**

## Licença

Projeto académico - uso livre para fins educacionais
